using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Kinectv1.Settings;
using Kinectv1.Voice;
using Kinectv1.Llm;

namespace Kinectv1.Services.Transcription
{
    /// <summary>
    /// Manages transcription-only mode: logs transcriptions to dated files and generates
    /// LLM summaries when the meeting ends. Supports speaker diarization.
    /// </summary>
    public sealed class TranscriptionService : IDisposable
    {
        private static TranscriptionService _instance;
        private static readonly object _lock = new object();

        public static TranscriptionService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new TranscriptionService();
                    }
                }
                return _instance;
            }
        }

        // Events
        public static event Action<string> OnLog;
        public static event Action<string> OnSummaryGenerated;
        public static event Action<string> OnTranscriptionFileCreated;
        public static event Action<string, string> OnSpeakerIdentified; // (label, text)

        // State
        private bool _isActive;
        private string _currentSessionFile;
        private DateTime _sessionStartTime;
        private DateTime _lastTranscriptionTime;
        private readonly List<TranscriptionEntry> _sessionEntries = new();
        private Timer _summaryTimer;
        private CancellationTokenSource _summaryCts;
        private readonly object _entriesLock = new object();

        // Voice embedding for diarization
        private float[] _lastEmbedding;
        private readonly object _embeddingLock = new object();
        private readonly object _embeddingSmoothLock = new();
        private readonly Queue<float[]> _embeddingWindow = new();
        private const int EmbeddingSmoothCount = 3;

        // WebRTC speaker boundary detection with hysteresis
        private string _activeSpeakerLabel;
        private string _pendingSpeakerLabel;
        private int _pendingSpeakerCount;
        private volatile bool _webrtcActive;

        // Embeddings hop ~500ms. We smooth diarization decisions across several hops.
        // A short majority window is more stable than simple consecutive-count when labels are noisy.
        private const int WebRtcSpeakerSwitchConfirmCount = 2;
        private const int WebRtcSpeakerMajorityWindow = 5; // ~2.5s
        private const int WebRtcSpeakerMajorityNeeded = 3; // majority within window
        private const float WebRtcMinBoundaryConfidence = 0.12f;

        private readonly Queue<(string label, float score)> _webrtcLabelWindow = new();

        // Don't force another boundary immediately after one (prevents ping-pong)
        private static readonly TimeSpan WebRtcSpeakerSwitchMinHold = TimeSpan.FromMilliseconds(800);
        private DateTime _lastWebRtcBoundaryUtc = DateTime.MinValue;

        // Segment index store (persistent)
        private TranscriptSegmentIndexStore _segmentStore;
        private LmStudioEmbeddingClient _segmentEmbeddingClient;
        private Task _segmentStoreLoadTask;
        private readonly SemaphoreSlim _segmentStoreIoMutex = new SemaphoreSlim(1, 1);
        private int _segmentIndexInSession = 0;

        // Rolling speaker history for segment attribution
        private readonly object _spkHistLock = new();
        private readonly Queue<(DateTime utc, string label, float score)> _spkHist = new();
        private const int SpeakerHistoryMaxSeconds = 20;

        private static readonly object _spkFallbackGate = new object();

        public bool IsActive => _isActive;
        public string CurrentSessionFile => _currentSessionFile;
        public int EntryCount { get { lock (_entriesLock) return _sessionEntries.Count; } }
        public int SpeakerCount => SpeakerDiarizer.Instance.SpeakerCount;

        /// <summary>
        /// Set whether WebRTC mode is active for speaker boundary detection.
        /// Use this instead of checking LastFrameSource which can be racy.
        /// </summary>
        public void SetWebRtcActive(bool active)
        {
            _webrtcActive = active;
            if (!active)
            {
                // Reset speaker boundary state when WebRTC is disabled
                _activeSpeakerLabel = null;
                _pendingSpeakerLabel = null;
                _pendingSpeakerCount = 0;
            }
        }

        private TranscriptionService() 
        {
            // Subscribe to voice embedding events
            SpeakerEmbedder.OnEmbedding += OnVoiceEmbedding;
        }

        private bool _transcriptionExHooked;

        private void OnVoiceEmbedding(float[] embedding)
        {
            // Store embedding regardless of session state (for speaker resolution later)
            lock (_embeddingLock)
            {
                _lastEmbedding = embedding;
            }

            if (embedding == null || embedding.Length == 0)
                return;

            // Identify speaker label from diarizer (A/B/C...)
            var (label, conf) = SpeakerDiarizer.Instance.IdentifyOrAssign(embedding);
            
            // Track a short window of labels to smooth decisions (WebRTC only).
            // Do this early so both boundary detection and dominant-speaker attribution can benefit.
            try
            {
                lock (_spkFallbackGate)
                {
                    _webrtcLabelWindow.Enqueue((label, conf));
                    while (_webrtcLabelWindow.Count > WebRtcSpeakerMajorityWindow)
                        _webrtcLabelWindow.Dequeue();
                }
            }
            catch { }

            // Record into rolling speaker history (used for dominant-speaker attribution on finalized segments)
            var nowUtc = DateTime.UtcNow;
            lock (_spkHistLock)
            {
                _spkHist.Enqueue((nowUtc, label, conf));
                while (_spkHist.Count > 0 && (nowUtc - _spkHist.Peek().utc).TotalSeconds > SpeakerHistoryMaxSeconds)
                    _spkHist.Dequeue();
            }

            // HARD GATE: only drive speaker boundaries when BOTH:
            // 1. WebRTC is explicitly active
            // 2. Transcription mode is enabled (we're in a transcription session)
            if (!_webrtcActive)
                return;

            if (string.IsNullOrWhiteSpace(label) || label.Equals("Unknown", StringComparison.OrdinalIgnoreCase))
                return;

            if (_activeSpeakerLabel == null)
            {
                _activeSpeakerLabel = label;
                _pendingSpeakerLabel = null;
                _pendingSpeakerCount = 0;
                Console.WriteLine($"[Diarizer] Initial speaker: {label}");
                return;
            }

            if (!label.Equals(_activeSpeakerLabel, StringComparison.OrdinalIgnoreCase))
            {
                // Majority smoothing gate: if the new label does not dominate recent frames, ignore it.
                // This stabilizes switching for embedding models with noisy cosine scores.
                try
                {
                    int cand = 0, cur = 0;
                    float candBest = 0f;
                    lock (_spkFallbackGate)
                    {
                        foreach (var (lab, sc) in _webrtcLabelWindow)
                        {
                            if (string.IsNullOrWhiteSpace(lab)) continue;
                            if (lab.Equals(label, StringComparison.OrdinalIgnoreCase))
                            {
                                cand++;
                                if (sc > candBest) candBest = sc;
                            }
                            else if (lab.Equals(_activeSpeakerLabel, StringComparison.OrdinalIgnoreCase))
                            {
                                cur++;
                            }
                        }
                    }

                    // Require the candidate to win the local vote by at least 1 and hit a small confidence floor.
                    if (cand < WebRtcSpeakerMajorityNeeded || cand <= cur || candBest < WebRtcMinBoundaryConfidence)
                    {
                        // Don't reset pending state here; just skip advancing on weak/noisy evidence.
                        return;
                    }
                }
                catch { }

                if (_pendingSpeakerLabel == null || !_pendingSpeakerLabel.Equals(label, StringComparison.OrdinalIgnoreCase))
                {
                    _pendingSpeakerLabel = label;
                    _pendingSpeakerCount = 1;
                    Console.WriteLine($"[Diarizer] Possible switch: {_activeSpeakerLabel} -> {label} (1/{WebRtcSpeakerSwitchConfirmCount})");
                }
                else
                {
                    _pendingSpeakerCount++;
                    if (_pendingSpeakerCount >= WebRtcSpeakerSwitchConfirmCount)
                    {
                        // Speaker switch confirmed -> force WebRTC boundary.
                        // Don't additionally gate on conf here: diarizer confidence is not a probability and
                        // can be low even on correct relative decisions. Instead use a hold window to avoid thrash.
                        if (_lastWebRtcBoundaryUtc == DateTime.MinValue || (nowUtc - _lastWebRtcBoundaryUtc) >= WebRtcSpeakerSwitchMinHold)
                        {
                            Console.WriteLine($"[Diarizer] SWITCH CONFIRMED: {_activeSpeakerLabel} -> {label} (conf={conf:F3})");
                            _lastWebRtcBoundaryUtc = nowUtc;
                            Kinectv1.VoiceRecognizer.ForceWebRtcBoundary("speaker_change");
                        }

                        _activeSpeakerLabel = label;
                        _pendingSpeakerLabel = null;
                        _pendingSpeakerCount = 0;
                    }
                }
            }
            else
            {
                // Same speaker - reset pending state silently
                _pendingSpeakerLabel = null;
                _pendingSpeakerCount = 0;
            }
        }

        /// <summary>
        /// Start a new transcription session.
        /// </summary>
        public void StartSession()
        {
            if (_isActive) return;

            var cfg = App.SettingsProvider?.Current?.Transcription;
            if (cfg == null)
            {
                Log("[Transcription] Settings unavailable");
                return;
            }

            _isActive = true;
            _sessionStartTime = DateTime.Now;
            _lastTranscriptionTime = _sessionStartTime;

            lock (_entriesLock)
            {
                _sessionEntries.Clear();
                _segmentIndexInSession = 0;
            }

            // Reset diarizer for new session
            SpeakerDiarizer.Instance.Reset();

            // Clear last embedding and speaker boundary state
            lock (_embeddingLock)
            {
                _lastEmbedding = null;
            }
            _activeSpeakerLabel = null;
            _pendingSpeakerLabel = null;
            _pendingSpeakerCount = 0;

            // Create output folder if needed
            var outputFolder = GetOutputFolder(cfg);
            try
            {
                if (!Directory.Exists(outputFolder))
                {
                    Directory.CreateDirectory(outputFolder);
                }
            }
            catch (Exception ex)
            {
                Log($"[Transcription] Failed to create output folder: {ex.Message}");
            }

            // Generate filename: Meeting_2024-01-15_14-30-00.txt
            var fileName = $"Meeting_{_sessionStartTime:yyyy-MM-dd_HH-mm-ss}.txt";
            _currentSessionFile = Path.Combine(outputFolder, fileName);

            // Ensure segment index is initialized now that we know output folder/session id
            try { EnsureSegmentIndexInitialized(); } catch { }

            // Write header
            try
            {
                File.WriteAllText(_currentSessionFile,
                    $"=== Meeting Transcription ===\n" +
                    $"Started: {_sessionStartTime:yyyy-MM-dd HH:mm:ss}\n" +
                    $"---\n\n",
                    Encoding.UTF8);

                OnTranscriptionFileCreated?.Invoke(_currentSessionFile);
                Log($"[Transcription] Session started: {_currentSessionFile}");
            }
            catch (Exception ex)
            {
                Log($"[Transcription] Failed to create session file: {ex.Message}");
            }

            // Start the summary timer if enabled
            if (cfg.GenerateSummary)
            {
                StartSummaryTimer(cfg.SummaryDelaySeconds);
            }

            // WebRTC-only: use word-timed utterances for correct speaker labeling.
            if (!_transcriptionExHooked)
            {
                _transcriptionExHooked = true;
                try
                {
                    Kinectv1.VoiceRecognizer.OnTranscriptionEx += utt =>
                    {
                        try
                        {
                            if (utt == null || !utt.IsFinal) return;
                            if (!_webrtcActive) return;
                            if (!_isActive) return;

                            var diarLabel = Services.Transcription.SpeakerDiarizer.Instance.GetDominantSpeaker(
                                utt.StartSample, utt.EndSample, fallback: _activeSpeakerLabel ?? "Unknown");

                            float[] emb = null;
                            try
                            {
                                if (Kinectv1.SpeakerEmbedder.TryGetEmbeddingForRange(utt.StartSample, utt.EndSample, out var avg) &&
                                    avg != null && avg.Length > 0)
                                {
                                    emb = avg;
                                }
                            }
                            catch { }

                            // Log transcription using diarized label. Keep it simple and avoid re-dispatching LLM here.
                            AddTranscription(diarLabel, utt.Text, emb);
                        }
                        catch { }
                    };
                }
                catch { }
            }
        }

        /// <summary>
        /// Stop the current transcription session and optionally generate a summary.
        /// </summary>
        public async Task StopSessionAsync(bool generateSummary = true)
        {
            if (!_isActive) return;

            _isActive = false;
            StopSummaryTimer();

            var cfg = App.SettingsProvider?.Current?.Transcription;

            // Finalize the file
            try
            {
                if (!string.IsNullOrEmpty(_currentSessionFile) && File.Exists(_currentSessionFile))
                {
                    var endTime = DateTime.Now;
                    var duration = endTime - _sessionStartTime;

                    // Get speaker statistics
                    var speakerStats = GetSpeakerStatistics();

                    File.AppendAllText(_currentSessionFile,
                        $"\n---\n" +
                        $"Ended: {endTime:yyyy-MM-dd HH:mm:ss}\n" +
                        $"Duration: {duration:hh\\:mm\\:ss}\n" +
                        $"Total entries: {EntryCount}\n" +
                        $"Speakers identified: {SpeakerDiarizer.Instance.SpeakerCount}\n" +
                        $"{speakerStats}\n",
                        Encoding.UTF8);
                }
            }
            catch (Exception ex)
            {
                Log($"[Transcription] Failed to finalize file: {ex.Message}");
            }

            // Generate summary if enabled and requested
            if (generateSummary && cfg?.GenerateSummary == true && EntryCount > 0)
            {
                await GenerateSummaryAsync();
            }

            Log($"[Transcription] Session ended. Total entries: {EntryCount}, Speakers: {SpeakerDiarizer.Instance.SpeakerCount}");

            lock (_entriesLock)
            {
                _sessionEntries.Clear();
            }
            _currentSessionFile = null;
        }

        /// <summary>
        /// Add a transcription entry to the current session with automatic speaker diarization.
        /// </summary>
        public void AddTranscription(string speaker, string text)
        {
            AddTranscription(speaker, text, null);
        }

        /// <summary>
        /// Add a transcription entry with explicit voice embedding for diarization.
        /// </summary>
        public void AddTranscription(string speaker, string text, float[] embedding)
        {
            if (!_isActive) return;
            if (string.IsNullOrWhiteSpace(text)) return;

            // Get embedding if not provided
            if (embedding == null)
            {
                lock (_embeddingLock)
                {
                    embedding = _lastEmbedding;
                }
            }

            // Estimate segment time window (used to pick dominant diarizer label)
            var segEndUtc = DateTime.UtcNow;
            double estimatedDurSec;
            try
            {
                var words = text.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;
                estimatedDurSec = words / 2.5;
            }
            catch
            {
                estimatedDurSec = 2.0;
            }
            estimatedDurSec = Math.Max(0.5, Math.Min(20.0, estimatedDurSec));
            var segStartUtc = segEndUtc.AddSeconds(-estimatedDurSec);

            // Determine the speaker label
            string resolvedSpeaker = ResolveSpeaker(speaker, embedding, segStartUtc, segEndUtc);

            var entry = new TranscriptionEntry
            {
                Timestamp = DateTime.Now,
                Speaker = resolvedSpeaker,
                Text = text.Trim()
            };

            int segIndex;
            lock (_entriesLock)
            {
                _sessionEntries.Add(entry);
                segIndex = _segmentIndexInSession;
                _segmentIndexInSession++;
            }

            _lastTranscriptionTime = entry.Timestamp;

            // Upsert segment + embedding metadata in background
            _ = Task.Run(async () =>
            {
                try { await UpsertTranscriptSegmentAsync(entry, speaker, embedding, segIndex).ConfigureAwait(false); }
                catch { }
            });

            // Notify listeners
            try { OnSpeakerIdentified?.Invoke(resolvedSpeaker, text); } catch { }

            // Append to file
            try
            {
                if (!string.IsNullOrEmpty(_currentSessionFile))
                {
                    var line = $"[{entry.Timestamp:HH:mm:ss}] {entry.Speaker}: {entry.Text}\n";
                    File.AppendAllText(_currentSessionFile, line, Encoding.UTF8);
                }
            }
            catch (Exception ex)
            {
                Log($"[Transcription] Failed to write entry: {ex.Message}");
            }

            // Reset summary timer
            var cfg = App.SettingsProvider?.Current?.Transcription;
            if (cfg?.GenerateSummary == true)
            {
                ResetSummaryTimer(cfg.SummaryDelaySeconds);
            }
        }

        private void StartSummaryTimer(int delaySeconds)
        {
            StopSummaryTimer();
            _summaryTimer = new Timer(OnSummaryTimerElapsed, null, 
                TimeSpan.FromSeconds(delaySeconds), 
                Timeout.InfiniteTimeSpan);
        }

        private void ResetSummaryTimer(int delaySeconds)
        {
            _summaryTimer?.Change(TimeSpan.FromSeconds(delaySeconds), Timeout.InfiniteTimeSpan);
        }

        private void StopSummaryTimer()
        {
            try
            {
                _summaryTimer?.Dispose();
                _summaryTimer = null;
                _summaryCts?.Cancel();
                _summaryCts = null;
            }
            catch { }
        }

        private void OnSummaryTimerElapsed(object state)
        {
            // Auto-generate summary after idle period
            if (_isActive && EntryCount > 0)
            {
                var timeSinceLastEntry = DateTime.Now - _lastTranscriptionTime;
                var cfg = App.SettingsProvider?.Current?.Transcription;

                if (timeSinceLastEntry.TotalSeconds >= (cfg?.SummaryDelaySeconds ?? 60))
                {
                    Log("[Transcription] Idle timeout reached, generating summary...");
                    _ = Task.Run(async () =>
                    {
                        await GenerateSummaryAsync();
                        // Don't stop the session automatically - user can continue
                    });
                }
            }
        }

        private static string GetOutputFolder(TranscriptionSettings cfg)
        {
            var folder = cfg?.OutputFolder ?? "transcriptions";
            if (!Path.IsPathRooted(folder))
            {
                folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, folder);
            }
            return folder;
        }

        private static void Log(string message)
        {
            try
            {
                Console.WriteLine(message);
                OnLog?.Invoke(message);
            }
            catch { }
        }

        private void EnsureSegmentIndexInitialized()
        {
            if (_segmentStore != null) return;

            try
            {
                // Prefer the active session's folder if available so recall can find it.
                // Fallback to settings folder for initialization outside a running session.
                string folder;
                try
                {
                    folder = !string.IsNullOrWhiteSpace(_currentSessionFile)
                        ? (Path.GetDirectoryName(_currentSessionFile) ?? GetOutputFolder(App.SettingsProvider?.Current?.Transcription))
                        : GetOutputFolder(App.SettingsProvider?.Current?.Transcription);
                }
                catch
                {
                    folder = GetOutputFolder(App.SettingsProvider?.Current?.Transcription);
                }

                Directory.CreateDirectory(folder);

                var path = Path.Combine(folder, "transcript_segments.json");
                _segmentStore = new TranscriptSegmentIndexStore(path);

                _segmentEmbeddingClient = new LmStudioEmbeddingClient(
                    App.SettingsProvider?.Current?.Ollama?.LmStudioBaseUrl ?? "http://127.0.0.1:1234",
                    App.SettingsProvider?.Current?.Ollama?.ApiKey,
                    () => App.SettingsProvider?.Current?.Ollama?.EmbeddingsModel);

                _segmentStoreLoadTask = Task.Run(async () =>
                {
                    await _segmentStoreIoMutex.WaitAsync().ConfigureAwait(false);
                    try { await _segmentStore.LoadAsync().ConfigureAwait(false); }
                    finally { _segmentStoreIoMutex.Release(); }
                });

                Console.WriteLine($"[TranscriptSegmentIndex] Using store: {path}");
            }
            catch (Exception ex)
            {
                Log($"[Transcription] Segment index init failed: {ex.Message}");
            }
        }

        private static string GetSessionIdFromSessionFile(string sessionFile)
        {
            if (string.IsNullOrWhiteSpace(sessionFile)) return string.Empty;
            try { return Path.GetFileNameWithoutExtension(sessionFile) ?? string.Empty; }
            catch { return string.Empty; }
        }

        private static string GetSessionTitleFromSessionFile(string sessionFile)
        {
            // Current sessions are named Meeting_yyyy-MM-dd_HH-mm-ss.txt
            // Title is stable and user-facing.
            return GetSessionIdFromSessionFile(sessionFile);
        }

        private double GetCurrentSessionElapsedSeconds(DateTime entryTimestampLocal)
        {
            try
            {
                var start = _sessionStartTime;
                var dt = entryTimestampLocal - start;
                if (dt.TotalSeconds < 0) return 0;
                return dt.TotalSeconds;
            }
            catch { return 0; }
        }

        private async Task UpsertTranscriptSegmentAsync(TranscriptionEntry entry, string providedSpeaker, float[] embedding)
            => await UpsertTranscriptSegmentAsync(entry, providedSpeaker, embedding, null).ConfigureAwait(false);

        private async Task UpsertTranscriptSegmentAsync(TranscriptionEntry entry, string providedSpeaker, float[] embedding, int? segIndexOverride)
        {
            try
            {
                EnsureSegmentIndexInitialized();
                if (_segmentStore == null) return;

                var load = _segmentStoreLoadTask;
                if (load != null) { try { await load.ConfigureAwait(false); } catch { } }

                // Prefer the diarizer label for grouping, but also keep the resolved speaker name.
                string speakerLabel = string.Empty;
                if (embedding != null && embedding.Length > 0)
                {
                    try
                    {
                        var (lab, _) = SpeakerDiarizer.Instance.IdentifyOrAssign(embedding);
                        speakerLabel = lab ?? string.Empty;
                    }
                    catch { }
                }

                var sessionId = GetSessionIdFromSessionFile(_currentSessionFile);
                var title = GetSessionTitleFromSessionFile(_currentSessionFile);

                double tEnd = GetCurrentSessionElapsedSeconds(entry.Timestamp);

                // Estimate start time by assuming the utterance is ~2.5 wps
                // (fallback only; true audio timestamps are not currently plumbed through.)
                double estimatedDur = 0;
                try
                {
                    var words = entry.Text?.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)?.Length ?? 0;
                    estimatedDur = words / 2.5;
                }
                catch { }
                estimatedDur = Math.Max(0.5, Math.Min(20.0, estimatedDur));

                double tStart = Math.Max(0, tEnd - estimatedDur);

                var startedAtUtc = _sessionStartTime.ToUniversalTime();
                var segIndex = segIndexOverride ?? _segmentIndexInSession;
                var segId = $"{sessionId}:{segIndex:D6}";

                float[] segEmbedding = null;
                try
                {
                    if (_segmentEmbeddingClient != null)
                        segEmbedding = await _segmentEmbeddingClient.GetEmbeddingAsync(entry.Text, CancellationToken.None).ConfigureAwait(false);
                }
                catch { }

                if (segEmbedding == null || segEmbedding.Length == 0)
                {
                    // Fall back to voice embedding if available (dimension may differ from query embeddings; tolerated).
                    segEmbedding = embedding;
                }

                var seg = new TranscriptSegment
                {
                    Id = segId,
                    SessionId = sessionId,
                    Title = title,
                    SpeakerLabel = speakerLabel,
                    SpeakerName = entry.Speaker,
                    Text = entry.Text,
                    TStartSec = tStart,
                    TEndSec = tEnd,
                    StartedAtUtc = startedAtUtc
                };

                if (segEmbedding != null && segEmbedding.Length > 0)
                    seg.SetEmbedding(segEmbedding);

                _segmentStore.UpsertSegment(seg);

                _ = Task.Run(async () =>
                {
                    try
                    {
                        await _segmentStoreIoMutex.WaitAsync().ConfigureAwait(false);
                        try { await _segmentStore.SaveAsync().ConfigureAwait(false); }
                        finally { _segmentStoreIoMutex.Release(); }
                    }
                    catch { }
                });
            }
            catch { }
        }

        public void Dispose()
        {
            StopSummaryTimer();
            _ = StopSessionAsync(false);
            
            // Unsubscribe from events
            try { SpeakerEmbedder.OnEmbedding -= OnVoiceEmbedding; } catch { }
            try { _segmentEmbeddingClient?.Dispose(); } catch { }
        }

        private class TranscriptionEntry
        {
            public DateTime Timestamp { get; set; }
            public string Speaker { get; set; }
            public string Text { get; set; }
        }

        /// <summary>
        /// Choose the dominant diarizer speaker label over a time window.
        /// Uses confidence-weighted votes so overlap/low-confidence windows don't dominate.
        /// </summary>
        private string GetDominantSpeakerLabel(DateTime segStartUtc, DateTime segEndUtc)
        {
            lock (_spkHistLock)
            {
                var counts = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

                foreach (var (utc, label, score) in _spkHist)
                {
                    if (utc < segStartUtc || utc > segEndUtc) continue;
                    if (string.IsNullOrWhiteSpace(label)) continue;
                    if (label.Equals("Unknown", StringComparison.OrdinalIgnoreCase)) continue;

                    var w = Math.Max(0.1, Math.Min(1.0, (double)score));
                    counts[label] = counts.TryGetValue(label, out var cur) ? cur + w : w;
                }

                if (counts.Count == 0)
                {
                    if (!string.IsNullOrWhiteSpace(_activeSpeakerLabel))
                        return _activeSpeakerLabel;
                    return "Unknown";
                }

                return counts.OrderByDescending(kv => kv.Value).First().Key;
            }
        }

        private string ResolveSpeaker(string providedSpeaker, float[] embedding, DateTime segStartUtc, DateTime segEndUtc)
        {
            if (!string.IsNullOrWhiteSpace(providedSpeaker) &&
                !providedSpeaker.Equals("UnknownSpeaker", StringComparison.OrdinalIgnoreCase) &&
                !providedSpeaker.Equals("Unknown", StringComparison.OrdinalIgnoreCase))
            {
                if (!providedSpeaker.StartsWith("Speaker ", StringComparison.OrdinalIgnoreCase))
                    return providedSpeaker;
            }

            if (embedding != null && embedding.Length > 0)
            {
                var (enrolledName, enrolledScore) = SpeakerIdentifier.IdentifyFromEmbedding(embedding);

                double threshold = 0.6;
                try { threshold = App.SettingsProvider?.Current?.Audio?.SpeakerMatchMinScore ?? 0.6; } catch { }

                if (!string.IsNullOrWhiteSpace(enrolledName) &&
                    !enrolledName.Equals("UnknownSpeaker", StringComparison.OrdinalIgnoreCase) &&
                    enrolledScore >= threshold)
                {
                    return enrolledName;
                }

                var dominant = GetDominantSpeakerLabel(segStartUtc, segEndUtc);
                if (!string.IsNullOrWhiteSpace(dominant) && !dominant.Equals("Unknown", StringComparison.OrdinalIgnoreCase))
                    return dominant;

                var (diarizedLabel, _) = SpeakerDiarizer.Instance.IdentifyOrAssign(embedding);
                return diarizedLabel;
            }

            if (!string.IsNullOrWhiteSpace(providedSpeaker) &&
                !providedSpeaker.Equals("UnknownSpeaker", StringComparison.OrdinalIgnoreCase))
            {
                return providedSpeaker;
            }

            return "Unknown";
        }

        // Back-compat overload
        private string ResolveSpeaker(string providedSpeaker, float[] embedding)
        {
            var now = DateTime.UtcNow;
            return ResolveSpeaker(providedSpeaker, embedding, now.AddSeconds(-3), now);
        }

        private string GetSpeakerStatistics()
        {
            List<TranscriptionEntry> entries;
            lock (_entriesLock)
            {
                entries = new List<TranscriptionEntry>(_sessionEntries);
            }

            if (entries.Count == 0)
                return "";

            var speakerCounts = entries
                .GroupBy(e => e.Speaker, StringComparer.OrdinalIgnoreCase)
                .Select(g => new { Speaker = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .ToList();

            var sb = new StringBuilder();
            sb.AppendLine("Speaker participation:");
            foreach (var sc in speakerCounts)
            {
                var pct = (sc.Count * 100.0 / entries.Count);
                sb.AppendLine($"  {sc.Speaker}: {sc.Count} entries ({pct:F1}%)");
            }

            return sb.ToString();
        }

        private async Task GenerateSummaryAsync()
        {
            List<TranscriptionEntry> entries;
            lock (_entriesLock)
            {
                entries = new List<TranscriptionEntry>(_sessionEntries);
            }

            if (entries.Count == 0)
            {
                Log("[Transcription] No entries to summarize");
                return;
            }

            Log("[Transcription] Generating meeting summary...");

            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("Please provide a brief summary of the following meeting transcript. Include:");
                sb.AppendLine("1. Main topics discussed");
                sb.AppendLine("2. Key decisions or action items");
                sb.AppendLine("3. Participants and their main contributions (note: speakers may be labeled as Speaker A, Speaker B, etc. if not enrolled)");
                sb.AppendLine();
                sb.AppendLine("Transcript:");
                sb.AppendLine("---");

                foreach (var entry in entries)
                {
                    sb.AppendLine($"[{entry.Timestamp:HH:mm:ss}] {entry.Speaker}: {entry.Text}");
                }

                sb.AppendLine("---");
                sb.AppendLine();
                sb.AppendLine("Provide a concise summary:");

                var prompt = sb.ToString();

                _summaryCts = new CancellationTokenSource();
                var summary = await GenerateLlmSummaryAsync(prompt, _summaryCts.Token).ConfigureAwait(false);

                if (!string.IsNullOrWhiteSpace(summary))
                {
                    if (!string.IsNullOrEmpty(_currentSessionFile) && File.Exists(_currentSessionFile))
                    {
                        File.AppendAllText(_currentSessionFile,
                            $"\n=== Meeting Summary ===\n{summary}\n",
                            Encoding.UTF8);
                    }

                    var summaryFileName = Path.ChangeExtension(_currentSessionFile, ".summary.txt");
                    File.WriteAllText(summaryFileName,
                        $"Meeting Summary\n" +
                        $"Date: {_sessionStartTime:yyyy-MM-dd HH:mm}\n" +
                        $"Duration: {(DateTime.Now - _sessionStartTime):hh\\:mm\\:ss}\n" +
                        $"Participants: {GetUniqueParticipants(entries)}\n" +
                        $"Speakers identified: {SpeakerDiarizer.Instance.SpeakerCount}\n\n" +
                        $"{summary}",
                        Encoding.UTF8);

                    Log($"[Transcription] Summary generated: {summaryFileName}");
                    try { OnSummaryGenerated?.Invoke(summary); } catch { }
                }
            }
            catch (OperationCanceledException)
            {
                Log("[Transcription] Summary generation cancelled");
            }
            catch (Exception ex)
            {
                Log($"[Transcription] Summary generation failed: {ex.Message}");
            }
        }

        private async Task<string> GenerateLlmSummaryAsync(string prompt, CancellationToken ct)
        {
            try
            {
                if (!OllamaService.IsEnabled())
                {
                    Log("[Transcription] LLM not available for summary generation");
                    return null;
                }

                var responseSb = new StringBuilder();
                var tcs = new TaskCompletionSource<string>();

                void OnChunk(string chunk)
                {
                    if (ct.IsCancellationRequested) return;
                    responseSb.Append(chunk);
                }

                void OnComplete(string response)
                {
                    tcs.TrySetResult(response);
                }

                void OnError(string error)
                {
                    Log($"[Transcription] LLM error: {error}");
                    tcs.TrySetResult(responseSb.ToString());
                }

                OllamaService.OnResponseChunk += OnChunk;
                OllamaService.OnResponseReceived += OnComplete;
                OllamaService.OnError += OnError;

                try
                {
                    await OllamaService.DispatchAsync("TranscriptionSummary", prompt, skipHistory: true).ConfigureAwait(false);

                    using var timeoutCts = new CancellationTokenSource(TimeSpan.FromMinutes(2));
                    using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(ct, timeoutCts.Token);

                    var completedTask = await Task.WhenAny(tcs.Task, Task.Delay(Timeout.Infinite, linkedCts.Token)).ConfigureAwait(false);
                    if (completedTask == tcs.Task)
                        return await tcs.Task.ConfigureAwait(false);

                    return responseSb.ToString();
                }
                finally
                {
                    OllamaService.OnResponseChunk -= OnChunk;
                    OllamaService.OnResponseReceived -= OnComplete;
                    OllamaService.OnError -= OnError;
                }
            }
            catch (Exception ex)
            {
                Log($"[Transcription] LLM summary error: {ex.Message}");
                return null;
            }
        }

        private string GetUniqueParticipants(List<TranscriptionEntry> entries)
        {
            var participants = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in entries)
            {
                if (!string.IsNullOrWhiteSpace(entry.Speaker) &&
                    !entry.Speaker.Equals("Unknown", StringComparison.OrdinalIgnoreCase))
                {
                    participants.Add(entry.Speaker);
                }
            }
            return participants.Count > 0 ? string.Join(", ", participants.OrderBy(p => p)) : "Unknown";
        }
    }
}
