// Settings/SettingsService.cs
using System;
using System.IO;
using System.Text;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;

namespace Kinectv1.Settings
{
    public sealed class SettingsService
    {
        private static readonly JsonSerializerSettings JsonSettings = new()
        {
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore,
            Converters = { new StringEnumConverter() }
        };

        private AppSettings _current;
        private readonly object _gate = new object();
        private readonly string _userPathOverride;

        public AppSettings Current { get { lock (_gate) return _current; } }

        public SettingsService(string userJsonPathOverride = null)
        {
            _userPathOverride = userJsonPathOverride;
            _current = LoadOrInitialize();
        }

        public AppSettings Reload()
        {
            lock (_gate)
            {
                _current = LoadComposite();
                return _current;
            }
        }

        public void Save(Func<AppSettings, AppSettings> update)
        {
            AppSettings next;
            lock (_gate) next = update(_current);

            Validate(next);

            var target = GetUserJsonPath();
            Directory.CreateDirectory(Path.GetDirectoryName(target));

            var tmp = target + ".tmp";
            using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
            using (var sw = new StreamWriter(fs, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false)))
            using (var jtw = new JsonTextWriter(sw) { Formatting = Formatting.Indented })
            {
                var ser = JsonSerializer.Create(JsonSettings);
                ser.Serialize(jtw, next);
            }

            var bak = target + ".bak";
            if (File.Exists(target))
            {
                File.Replace(tmp, target, bak);
            }
            else
            {
                if (File.Exists(bak)) File.Delete(bak);
                File.Move(tmp, target);
                File.Copy(target, bak, overwrite: true);
            }

            lock (_gate) _current = next;
        }

        // ----- externals -----
        public AppSettings GetDefaults()
        {
            var json = ReadEmbeddedDefaultJson();
            var obj = JsonConvert.DeserializeObject<AppSettings>(json, JsonSettings);
            if (obj == null) throw new InvalidDataException("default.json is invalid");
            Validate(obj);
            return obj;
        }

        public static void ValidateOrThrow(AppSettings s) => Validate(s);

        // ----- internals -----
        private AppSettings LoadOrInitialize()
        {
            var target = GetUserJsonPath();
            if (!File.Exists(target))
            {
                var defaults = ReadDefaultsAsAppSettings();
                Validate(defaults);
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                var tmp = target + ".tmp";
                File.WriteAllText(tmp, JsonConvert.SerializeObject(defaults, JsonSettings), new UTF8Encoding(false));
                var bak = target + ".bak";
                File.Move(tmp, target);
                File.Copy(target, bak, overwrite: true);
                return defaults;
            }
            return LoadComposite();
        }

        private AppSettings LoadComposite()
        {
            var defaultsJson = ReadEmbeddedDefaultJson();
            var composite = JObject.Parse(defaultsJson);

            JObject userObj = null;
            if (File.Exists(GetUserJsonPath()))
            {
                var userJson = File.ReadAllText(GetUserJsonPath(), Encoding.UTF8);
                if (!string.IsNullOrWhiteSpace(userJson))
                {
                    userObj = JObject.Parse(userJson);
                    DeepMerge(composite, userObj);
                }
            }

            bool changed = false;
            changed |= NormalizeSectionCasing(composite);

            var defaultsObj = JObject.Parse(defaultsJson);
            changed |= BackfillTts(composite, defaultsObj);
            changed |= BackfillOllama(composite, defaultsObj);
            changed |= BackfillDiscord(composite, defaultsObj);
            changed |= BackfillMumble(composite, defaultsObj);

            if (changed)
            {
                PersistNormalizedUserJson(composite);
            }

            var result = composite.ToObject<AppSettings>(JsonSerializer.Create(JsonSettings));
            if (result == null) throw new InvalidDataException("Merged settings invalid");
            Validate(result);
            return result;
        }

        // Deep-merge user JSON into defaults JSON (objects only)
        private static void DeepMerge(JObject dst, JObject src)
        {
            foreach (var p in src.Properties())
            {
                if (p.Value is JObject srcObj)
                {
                    if (dst[p.Name] is JObject dstObj)
                        DeepMerge(dstObj, srcObj);
                    else
                        dst[p.Name] = srcObj.DeepClone();
                }
                else
                {
                    dst[p.Name] = p.Value.DeepClone();
                }
            }
        }

        private void PersistNormalizedUserJson(JObject normalized)
        {
            try
            {
                var target = GetUserJsonPath();
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                var tmp = target + ".tmp";
                using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
                using (var sw = new StreamWriter(fs, new UTF8Encoding(false)))
                using (var jtw = new JsonTextWriter(sw) { Formatting = Formatting.Indented })
                {
                    var ser = JsonSerializer.Create(JsonSettings);
                    ser.Serialize(jtw, normalized);
                }
                var bak = target + ".bak";
                if (File.Exists(target))
                {
                    File.Replace(tmp, target, bak);
                }
                else
                {
                    if (File.Exists(bak)) File.Delete(bak);
                    File.Move(tmp, target);
                    File.Copy(target, bak, overwrite: true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Settings migration write failed: {ex.Message}");
            }
        }

        private static bool NormalizeSectionCasing(JObject root)
        {
            bool changed = false;
            if (root == null) return changed;

            void MergeInto(string lowerName, string upperName)
            {
                var upper = root[upperName] as JObject;
                if (upper == null) return;
                var lower = root[lowerName] as JObject;
                if (lower == null)
                {
                    lower = new JObject();
                    root[lowerName] = lower;
                }
                foreach (var p in upper.Properties())
                {
                    var name = p.Name;
                    if (string.IsNullOrEmpty(name)) continue;
                    var lc = char.ToLowerInvariant(name[0]) + name.Substring(1);
                    lower[lc] = p.Value.DeepClone();
                }
                root.Remove(upperName);
                changed = true;
            }

            MergeInto("audio", "Audio");
            MergeInto("tts", "Tts");
            MergeInto("vad", "Vad");
            MergeInto("ollama", "Ollama");
            MergeInto("discord", "Discord");
            MergeInto("mumble", "Mumble");
            return changed;
        }

        private static bool BackfillTts(JObject composite, JObject defaults)
        {
            bool changed = false;
            var tts = composite?[(string)"tts"] as JObject;
            var dTts = defaults?[(string)"tts"] as JObject;
            if (tts == null || dTts == null) return changed;

            void Ensure(string name, Func<JToken, bool> invalid)
            {
                var token = tts[name];
                if (token == null || invalid(token))
                {
                    tts[name] = dTts[name]?.DeepClone();
                    changed = true;
                }
            }

            bool IsNumberInvalidInRange(JToken tok, double min, double max)
            {
                if (tok == null || tok.Type == JTokenType.Null) return true;
                double v;
                try { v = tok.Value<double>(); } catch { return true; }
                return v < min || v > max;
            }

            Ensure("outputDevice", tok => tok.Type != JTokenType.String || string.IsNullOrWhiteSpace(tok.Value<string>()));
            Ensure("localVolume", tok => IsNumberInvalidInRange(tok, 0.0, 1.0));
            Ensure("discordVolume", tok => IsNumberInvalidInRange(tok, 0.0, 1.0));
            Ensure("speed", tok => IsNumberInvalidInRange(tok, 0.5, 2.0));
            Ensure("trimThreshold", tok => IsNumberInvalidInRange(tok, 0.0005, 0.05));
            Ensure("trimLeaveMs", tok => IsNumberInvalidInRange(tok, 0, 100));
            Ensure("trimMaxMs", tok => IsNumberInvalidInRange(tok, 50, 3000));
            Ensure("minClausePaddingMs", tok => IsNumberInvalidInRange(tok, 0, 200));
            Ensure("ipaServiceTimeoutMs", tok => IsNumberInvalidInRange(tok, 200, 5000));
            Ensure("ipaOneShotTimeoutMs", tok => IsNumberInvalidInRange(tok, 200, 5000));

            return changed;
        }

        // New: Ensure Ollama section has required fields and defaults
        private static bool BackfillOllama(JObject composite, JObject defaults)
        {
            bool changed = false;
            var ol = composite?[(string)"ollama"] as JObject;
            var dOl = defaults?[(string)"ollama"] as JObject;
            if (dOl == null)
                return changed;
            if (ol == null)
            {
                composite["ollama"] = dOl.DeepClone();
                return true;
            }

            void EnsureString(string name)
            {
                var tok = ol[name];
                if (tok == null || tok.Type != JTokenType.String)
                {
                    ol[name] = dOl[name]?.DeepClone();
                    changed = true;
                }
            }

            void EnsureInt(string name)
            {
                var tok = ol[name];
                if (tok == null || tok.Type != JTokenType.Integer)
                {
                    ol[name] = dOl[name]?.DeepClone();
                    changed = true;
                }
            }

            void EnsureBool(string name)
            {
                var tok = ol[name];
                if (tok == null || tok.Type != JTokenType.Boolean)
                {
                    ol[name] = dOl[name]?.DeepClone();
                    changed = true;
                }
            }

            EnsureString("provider");
            EnsureBool("enabled");
            EnsureString("model");
            EnsureBool("memoryEnabled");
            EnsureInt("maxMessagesPerSpeaker");
            EnsureInt("maxSystemMessages");
            EnsureInt("conversationTimeoutMinutes");
            EnsureString("conversationHistoryPath");
            EnsureString("systemPromptPath");
            EnsureBool("outputThink");

            return changed;
        }

        // New: Ensure Discord section present
        private static bool BackfillDiscord(JObject composite, JObject defaults)
        {
            bool changed = false;
            var dc = composite?[(string)"discord"] as JObject;
            var dDc = defaults?[(string)"discord"] as JObject;
            if (dDc == null) return changed;
            if (dc == null)
            {
                composite["discord"] = dDc.DeepClone();
                return true;
            }

            void EnsureString(string name)
            {
                var tok = dc[name];
                if (tok == null || tok.Type != JTokenType.String)
                {
                    dc[name] = dDc[name]?.DeepClone();
                    changed = true;
                }
            }

            void EnsureBool(string name)
            {
                var tok = dc[name];
                if (tok == null || tok.Type != JTokenType.Boolean)
                {
                    dc[name] = dDc[name]?.DeepClone();
                    changed = true;
                }
            }

            EnsureBool("enabled");
            EnsureString("prefix");
            EnsureBool("autoJoinVoice");
            EnsureString("token");
            return changed;
        }

        // New: Ensure Mumble section present
        private static bool BackfillMumble(JObject composite, JObject defaults)
        {
            bool changed = false;
            var mb = composite?[(string)"mumble"] as JObject;
            var dMb = defaults?[(string)"mumble"] as JObject;
            if (dMb == null) return changed;
            if (mb == null)
            {
                composite["mumble"] = dMb.DeepClone();
                return true;
            }

            void EnsureString(string name)
            {
                var tok = mb[name];
                if (tok == null || tok.Type != JTokenType.String)
                {
                    mb[name] = dMb[name]?.DeepClone();
                    changed = true;
                }
            }
            void EnsureInt(string name)
            {
                var tok = mb[name];
                if (tok == null || tok.Type != JTokenType.Integer)
                {
                    mb[name] = dMb[name]?.DeepClone();
                    changed = true;
                }
            }
            void EnsureBool(string name)
            {
                var tok = mb[name];
                if (tok == null || tok.Type != JTokenType.Boolean)
                {
                    mb[name] = dMb[name]?.DeepClone();
                    changed = true;
                }
            }

            EnsureBool("enabled");
            EnsureBool("autoConnect");
            EnsureString("host");
            EnsureInt("port");
            EnsureString("username");
            EnsureString("serverPassword");
            EnsureString("channel");
            EnsureString("channelPassword");
            EnsureBool("validateTls");
            EnsureBool("selfMute");
            EnsureBool("selfDeaf");
            EnsureInt("opusBitrate");
            EnsureInt("vadThreshold");
            EnsureInt("reconnectBackoffMs");
            EnsureBool("textCommandsEnabled");

            return changed;
        }

        private string ReadEmbeddedDefaultJson()
        {
            var asm = typeof(SettingsService).Assembly;
            var resName = SettingsPaths.DefaultResourceName;
            using var s = asm.GetManifestResourceStream(resName) ?? throw new FileNotFoundException("default.json resource missing");
            using var sr = new StreamReader(s, Encoding.UTF8, true);
            return sr.ReadToEnd();
        }

        private AppSettings ReadDefaultsAsAppSettings()
        {
            var json = ReadEmbeddedDefaultJson();
            var obj = JsonConvert.DeserializeObject<AppSettings>(json, JsonSettings);
            if (obj == null) throw new InvalidDataException("default.json is invalid");
            return obj;
        }

        private string GetUserJsonPath() => _userPathOverride ?? SettingsPaths.UserJsonPath;

        private static void Validate(AppSettings s)
        {
            if (s == null || s.Audio == null || s.Tts == null || s.Vad == null)
                throw new InvalidDataException("Settings missing required sections (audio/tts/vad)");

            if (s.Audio.VoiceThreshold < 0.0 || s.Audio.VoiceThreshold > 1.0)
                throw new InvalidDataException("audio.voiceThreshold out of range [0,1]");
            if (s.Audio.VadThreshold < 0 || s.Audio.BufferSize <= 0)
                throw new InvalidDataException("audio vadThreshold>=0 and bufferSize>0 required");

            // TTS basics
            if (s.Tts.Enabled)
            {
                if (string.IsNullOrWhiteSpace(s.Tts.ModelFolder)) throw new InvalidDataException("tts.modelFolder required when tts.enabled");
                if (string.IsNullOrWhiteSpace(s.Tts.ModelPath)) throw new InvalidDataException("tts.modelPath required when tts.enabled");
                if (string.IsNullOrWhiteSpace(s.Tts.VocoderPath)) throw new InvalidDataException("tts.vocoderPath required when tts.enabled");
            }

            // TTS extended fields validation (ranges)
            if (s.Tts.LocalVolume < 0.0 || s.Tts.LocalVolume > 1.0)
                throw new InvalidDataException("tts.localVolume must be 0..1");
            if (s.Tts.DiscordVolume < 0.0 || s.Tts.DiscordVolume > 1.0)
                throw new InvalidDataException("tts.discordVolume must be 0..1");
            if (s.Tts.Speed < 0.5f || s.Tts.Speed > 2.0f)
                throw new InvalidDataException("tts.speed must be 0.5..2.0");
            if (s.Tts.TrimThreshold < 0.0005 || s.Tts.TrimThreshold > 0.05)
                throw new InvalidDataException("tts.trimThreshold must be 0.0005..0.05");
            if (s.Tts.TrimLeaveMs < 0 || s.Tts.TrimLeaveMs > 100)
                throw new InvalidDataException("tts.trimLeaveMs must be 0..100");
            if (s.Tts.TrimMaxMs < 50 || s.Tts.TrimMaxMs > 3000)
                throw new InvalidDataException("tts.trimMaxMs must be 50..3000");
            if (s.Tts.MinClausePaddingMs < 0 || s.Tts.MinClausePaddingMs > 200)
                throw new InvalidDataException("tts.minClausePaddingMs must be 0..200");
            if (s.Tts.IpaServiceTimeoutMs < 200 || s.Tts.IpaServiceTimeoutMs > 5000)
                throw new InvalidDataException("tts.ipaServiceTimeoutMs must be 200..5000");
            if (s.Tts.IpaOneShotTimeoutMs < 200 || s.Tts.IpaOneShotTimeoutMs > 5000)
                throw new InvalidDataException("tts.ipaOneShotTimeoutMs must be 200..5000");

            // Ollama validation
            if (s.Ollama == null)
                throw new InvalidDataException("ollama section missing");
            if (string.IsNullOrWhiteSpace(s.Ollama.Provider))
                throw new InvalidDataException("ollama.provider required (Ollama|LMStudio)");
            var prov = s.Ollama.Provider.Trim();
            if (!string.Equals(prov, "Ollama", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(prov, "LMStudio", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("ollama.provider must be 'Ollama' or 'LMStudio'");

            if (s.Ollama.Enabled)
            {
                // Model must be set when enabled
                if (string.IsNullOrWhiteSpace(s.Ollama.Model))
                    throw new InvalidDataException("ollama.model required when ollama.enabled");
            }
            if (s.Ollama.MaxMessagesPerSpeaker < 0 || s.Ollama.MaxSystemMessages < 0)
                throw new InvalidDataException("ollama max message counts must be >= 0");
            if (s.Ollama.ConversationTimeoutMinutes < 0)
                throw new InvalidDataException("ollama.conversationTimeoutMinutes must be >= 0");
            // OutputThink is a boolean and needs no additional range validation

            // Discord validation
            if (s.Discord == null)
                throw new InvalidDataException("discord section missing");
            if (s.Discord.Enabled)
            {
                if (string.IsNullOrWhiteSpace(s.Discord.Prefix))
                    throw new InvalidDataException("discord.prefix required when discord.enabled");
                if (string.IsNullOrWhiteSpace(s.Discord.Token) || s.Discord.Token.Length < 24)
                    throw new InvalidDataException("discord.token appears invalid or missing when discord.enabled");
            }

            // Mumble validation
            if (s.Mumble == null)
                throw new InvalidDataException("mumble section missing");
            if (s.Mumble.Enabled)
            {
                if (string.IsNullOrWhiteSpace(s.Mumble.Host))
                    throw new InvalidDataException("mumble.host required when mumble.enabled");
                if (s.Mumble.Port <= 0 || s.Mumble.Port > 65535)
                    throw new InvalidDataException("mumble.port must be 1..65535");
                if (string.IsNullOrWhiteSpace(s.Mumble.Username))
                    throw new InvalidDataException("mumble.username required when mumble.enabled");
                if (s.Mumble.OpusBitrate < 6000 || s.Mumble.OpusBitrate > 96000)
                    throw new InvalidDataException("mumble.opusBitrate must be 6000..96000");
                if (s.Mumble.VadThreshold < 1 || s.Mumble.VadThreshold > 10000)
                    throw new InvalidDataException("mumble.vadThreshold must be 1..10000");
                if (s.Mumble.ReconnectBackoffMs < 0 || s.Mumble.ReconnectBackoffMs > 60000)
                    throw new InvalidDataException("mumble.reconnectBackoffMs must be 0..60000");
            }
        }
    }
}
