using System;

namespace Kinectv1.Services.Voice
{
    public sealed class TranscribedUtterance
    {
        public string Text { get; init; } = "";
        public double StartSec { get; init; }
        public double EndSec { get; init; }
        public long StartSample { get; init; }
        public long EndSample { get; init; }
        public string RawJson { get; init; } = "";
        public bool IsFinal { get; init; } = true;
    }
}
