using System;
using System.Collections.Generic;
using System.Linq;

namespace Kinectv1.Services.Transcription
{
    /// <summary>
    /// Speaker diarization for transcription mode.
    /// Tracks and labels speakers (Speaker A, B, C...) based on voice embeddings
    /// when speakers are not enrolled in the main SpeakerIdentifier.
    /// </summary>
    public sealed class SpeakerDiarizer
    {
        private static readonly Lazy<SpeakerDiarizer> _instance = new(() => new SpeakerDiarizer());
        public static SpeakerDiarizer Instance => _instance.Value;

        private sealed class Cluster
        {
            public string Label;
            public float[] Centroid;
            public int Support;
            public DateTime LastSeenUtc;
        }

        // Speaker clusters: label -> centroid/stats
        private readonly Dictionary<string, Cluster> _clusters = new(StringComparer.OrdinalIgnoreCase);
        private readonly object _lock = new();

        // Timeline of diarization decisions (WebRTC transcript labeling)
        private readonly List<(long s, long e, string label, float score)> _timeline = new();
        private const int MaxTimeline = 2000;

        private int _nextLabelIndex = 0;

        // Tunables (fallback defaults)
        // ECAPA / WeSpeaker cosine similarity defaults (starting points)
        private const double DefaultSameSpeakerThreshold = 0.45;
        private const double DefaultNewSpeakerThreshold = 0.35;
        private const double DefaultMinMargin = 0.05;
        private const double DefaultUpdateAlpha = 0.08;
        private const int DefaultNewSpeakerConsecutive = 4;
        private const int DefaultNewSpeakerCooldownMs = 3000;
        private const int DefaultMaxClusters = 6;
        private const double DefaultOverlapScoreBand = 0.03;

        // Anti-ping-pong switching guards
        // Margin needed to *consider* switching speakers (separate from cluster creation thresholding).
        private const double DefaultMinSwitchMargin = 0.03;
        private const int DefaultMinSpeakerHoldMs = 800;

        // Switching tunables (starting points)
        private const int DefaultSwitchConfirmCount = 2;
        private const int DefaultMinSpeakerHoldMs2 = 400;

        private const string LabelPrefix = "Speaker ";

        // If best/second are nearly tied (or overall similarity is weak), don't advance switch state.
        // This is the main reason switches can appear to "never happen" in noisy overlap segments.
        private const double DefaultAmbiguousMargin = 0.02;
        private const double DefaultWeakBestBand = 0.02;

        private DateTime _lastNewSpeakerUtc = DateTime.MinValue;
        private int _belowNewSpeakerThresholdCount = 0;

        private string _currentSpeaker = null;
        private DateTime _lastSwitchUtc = DateTime.MinValue;

        // Switch candidate tracking (inside diarizer, not ASR boundaries)
        private string _pendingSpeaker = null;
        private int _pendingSpeakerCount = 0;

        private SpeakerDiarizer() { }

        public void Reset()
        {
            lock (_lock)
            {
                _clusters.Clear();
                _timeline.Clear();
                _nextLabelIndex = 0;
                _lastNewSpeakerUtc = DateTime.MinValue;
                _belowNewSpeakerThresholdCount = 0;
                _currentSpeaker = null;
                _lastSwitchUtc = DateTime.MinValue;
                _pendingSpeaker = null;
                _pendingSpeakerCount = 0;
                Console.WriteLine("[Diarizer] Reset - all clusters cleared");
            }
        }

        public int SpeakerCount
        {
            get { lock (_lock) return _clusters.Count; }
        }

        public string[] GetSpeakerLabels()
        {
            lock (_lock)
            {
                return _clusters.Keys.OrderBy(k => k).ToArray();
            }
        }

        public (string label, float confidence) IdentifyOrAssign(float[] embedding)
        {
            if (embedding == null || embedding.Length == 0) return ("Unknown", 0f);
            for (int i = 0; i < embedding.Length; i++)
            {
                if (float.IsNaN(embedding[i]) || float.IsInfinity(embedding[i]))
                    return ("Unknown", 0f);
            }

            lock (_lock)
            {
                double sameThr = GetSameSpeakerThreshold();
                double newThr = GetNewSpeakerThreshold();
                double minMargin = GetMinSwitchMargin();
                int maxClusters = GetMaxClusters();

                // First speaker always
                if (_clusters.Count == 0)
                {
                    var label0 = GetNextLabel();
                    _clusters[label0] = new Cluster
                    {
                        Label = label0,
                        Centroid = (float[])embedding.Clone(),
                        Support = 1,
                        LastSeenUtc = DateTime.UtcNow
                    };
                    _lastNewSpeakerUtc = DateTime.UtcNow;
                    _belowNewSpeakerThresholdCount = 0;
                    _currentSpeaker = label0;
                    _lastSwitchUtc = DateTime.UtcNow;
                    return (label0, 1f);
                }

                // Find best + second best
                string best = null, second = null;
                double bestScore = double.NegativeInfinity;
                double secondScore = double.NegativeInfinity;

                foreach (var kv in _clusters)
                {
                    var sim = CosineSimilarity(embedding, kv.Value.Centroid);
                    if (sim > bestScore)
                    {
                        secondScore = bestScore; second = best;
                        bestScore = sim; best = kv.Key;
                    }
                    else if (sim > secondScore)
                    {
                        secondScore = sim; second = kv.Key;
                    }
                }

                double margin = bestScore - secondScore;

                // Soft overlap indicator
                bool nearThreshold = bestScore < (sameThr + DefaultOverlapScoreBand);
                bool lowMargin = _clusters.Count >= 2 && margin < minMargin;
                bool overlapped = (_clusters.Count >= 2) && (nearThreshold || lowMargin);

                // Confidence weight (0..1)
                double scoreConf = Clamp01((bestScore - sameThr) / 0.10);
                double marginConf = (_clusters.Count < 2) ? 1.0 : Clamp01(margin / (minMargin * 2.0));
                double w = scoreConf * marginConf;

                var now = DateTime.UtcNow;

                // Initialize tracking if needed
                if (string.IsNullOrWhiteSpace(_currentSpeaker) || !_clusters.ContainsKey(_currentSpeaker))
                    _currentSpeaker = best;

                // Logging (keep existing pattern)
                bool isSignificantEvent = (best != null && bestScore < sameThr) || (_clusters.Count > 1 && margin < 0.1);
                bool shouldLog = _clusters.Count > 0 && ((now - _lastLogTime).TotalSeconds >= 10.0 || isSignificantEvent);
                if (shouldLog)
                {
                    Console.WriteLine($"[Diarizer] Scores: best={best}({bestScore:F3}), second={second}({secondScore:F3}), margin={margin:F3}, sameThr={sameThr:F3}, newThr={newThr:F3}, clusters={_clusters.Count}");
                    _lastLogTime = now;
                }

                // Anti-chatter: minimum hold time before allowing switches.
                // If we are within the hold window, keep the current speaker stable.
                // Ambiguity / overlap: if the margin is tiny, don�t switch and don�t learn.
                // Keep the current speaker stable.
                // IMPORTANT: ambiguity for *switching* should be lower than minMargin (which also impacts new speaker logic).
                // Otherwise we end up never accumulating confirmations when speakers are close.
                double switchMarginThr = Math.Max(DefaultMinSwitchMargin, DefaultAmbiguousMargin);
                bool weakBest = bestScore < (newThr + DefaultWeakBestBand);
                bool ambiguous = (_clusters.Count >= 2) && (margin < switchMarginThr);

                // Respect hold time (but lower than 800ms so switching can actually happen)
                if (!string.IsNullOrWhiteSpace(_currentSpeaker) && _lastSwitchUtc != DateTime.MinValue &&
                    (now - _lastSwitchUtc).TotalMilliseconds < DefaultMinSpeakerHoldMs2)
                {
                    // During hold window, don�t advance switching state.
                    _pendingSpeaker = null;
                    _pendingSpeakerCount = 0;

                    // Allow learning only for the locked speaker on very confident frames.
                    if (_clusters.TryGetValue(_currentSpeaker, out var holdCluster))
                    {
                        var holdScore = CosineSimilarity(embedding, holdCluster.Centroid);
                        if (holdScore >= (sameThr + 0.05))
                            UpdateCentroid(holdCluster, embedding, alpha: DefaultUpdateAlpha);
                        holdCluster.LastSeenUtc = now;
                    }

                    return (_currentSpeaker, (float)Math.Max(0.01, bestScore));
                }

                if (ambiguous || weakBest)
                {
                    // Overlap/weak frame: don�t switch, don�t build pending confirmations.
                    _pendingSpeaker = null;
                    _pendingSpeakerCount = 0;

                    return (!string.IsNullOrWhiteSpace(_currentSpeaker) ? _currentSpeaker : (best ?? "Unknown"),
                        (float)Math.Max(0.01, bestScore));
                }

                // If best != current, allow switching even when bestScore < sameThr,
                // as long as it's above newThr and wins by margin (non-ambiguous).
                if (!string.IsNullOrWhiteSpace(best) &&
                    !string.IsNullOrWhiteSpace(_currentSpeaker) &&
                    !string.Equals(best, _currentSpeaker, StringComparison.OrdinalIgnoreCase) &&
                    bestScore >= newThr)
                {
                    if (_pendingSpeaker == null || !_pendingSpeaker.Equals(best, StringComparison.OrdinalIgnoreCase))
                    {
                        _pendingSpeaker = best;
                        _pendingSpeakerCount = 1;
                    }
                    else
                    {
                        _pendingSpeakerCount++;
                    }

                    if (_pendingSpeakerCount >= DefaultSwitchConfirmCount)
                    {
                        _currentSpeaker = best;
                        _lastSwitchUtc = now;
                        _pendingSpeaker = null;
                        _pendingSpeakerCount = 0;
                    }

                    // Return stable current speaker label (after possible switch)
                    return (_currentSpeaker, (float)Math.Max(0.01, bestScore));
                }

                // If best == current, clear pending
                _pendingSpeaker = null;
                _pendingSpeakerCount = 0;

                // Match
                if (!string.IsNullOrWhiteSpace(best) && bestScore >= sameThr)
                {
                    var c = _clusters[best];

                    // Reduce centroid drift: only update on confident matches.
                    //  - For 1 cluster, require a bit above sameThr.
                    //  - For 2+ clusters, also require margin.
                    bool canLearn = bestScore >= (sameThr + 0.05) && margin >= 0.06;
                    if (canLearn && w > 0.05)
                    {
                        UpdateCentroid(c, embedding, alpha: DefaultUpdateAlpha * w);
                        c.Support++;
                    }
                    c.LastSeenUtc = now;

                    // Reset unknown streak on confident match
                    if (w >= 0.2)
                        _belowNewSpeakerThresholdCount = 0;

                    // Speaker switch bookkeeping (only when we really changed label)
                    if (!string.IsNullOrWhiteSpace(best) && !string.Equals(_currentSpeaker, best, StringComparison.OrdinalIgnoreCase))
                    {
                        _currentSpeaker = best;
                        _lastSwitchUtc = now;
                    }
                    else if (!string.IsNullOrWhiteSpace(best))
                    {
                        _currentSpeaker = best;
                    }

                    return (best, (float)bestScore);
                }

                // Below threshold: candidate for new speaker
                if (!overlapped && ShouldCreateNewSpeaker(bestScore, newThr, now, maxClusters))
                {
                    var newLabel = GetNextLabel();
                    _clusters[newLabel] = new Cluster
                    {
                        Label = newLabel,
                        Centroid = (float[])embedding.Clone(),
                        Support = 1,
                        LastSeenUtc = now
                    };

                    _lastNewSpeakerUtc = now;
                    _belowNewSpeakerThresholdCount = 0;
                    _currentSpeaker = newLabel;
                    _lastSwitchUtc = now;
                    Console.WriteLine($"[Diarizer] NEW SPEAKER: {newLabel} (best={best}:{bestScore:F3} < newThr={newThr:F3}, clusters={_clusters.Count})");
                    return (newLabel, 1f);
                }

                // Hard clamp: if we're already at/over max clusters, never create new labels.
                // Return best guess or Unknown.
                if (!string.IsNullOrWhiteSpace(best))
                {
                    if (string.IsNullOrWhiteSpace(_currentSpeaker)) _currentSpeaker = best;
                    return (best, (float)Math.Max(0.01, bestScore));
                }

                return ("Unknown", 0f);
            }
        }

        private static DateTime _lastLogTime = DateTime.MinValue;

        public (string label, float confidence) Identify(float[] embedding)
        {
            if (embedding == null || embedding.Length == 0) return ("Unknown", 0f);

            lock (_lock)
            {
                if (_clusters.Count == 0) return ("Unknown", 0f);

                string best = null;
                double bestScore = double.NegativeInfinity;

                foreach (var kv in _clusters)
                {
                    var sim = CosineSimilarity(embedding, kv.Value.Centroid);
                    if (sim > bestScore)
                    {
                        bestScore = sim;
                        best = kv.Key;
                    }
                }

                double thr = GetSameSpeakerThreshold();
                if (best != null && bestScore >= thr)
                    return (best, (float)bestScore);

                return ("Unknown", (float)Math.Max(0, bestScore));
            }
        }

        public bool MergeSpeakers(string label1, string label2)
        {
            // Online auto-merge is intentionally avoided; manual merge kept for operator corrections.
            lock (_lock)
            {
                if (!_clusters.TryGetValue(label1, out var c1) || !_clusters.TryGetValue(label2, out var c2))
                    return false;

                if (c1?.Centroid == null || c2?.Centroid == null) return false;

                // Merge by averaging centroids weighted by support.
                int w1 = Math.Max(1, c1.Support);
                int w2 = Math.Max(1, c2.Support);
                int tot = w1 + w2;

                for (int i = 0; i < c1.Centroid.Length && i < c2.Centroid.Length; i++)
                    c1.Centroid[i] = (float)((c1.Centroid[i] * w1 + c2.Centroid[i] * w2) / tot);

                c1.Support = tot;
                c1.LastSeenUtc = DateTime.UtcNow;

                _clusters.Remove(label2);
                Console.WriteLine($"[Diarizer] Merged {label2} into {label1}");
                return true;
            }
        }

        public Dictionary<string, int> GetClusterStats()
        {
            lock (_lock)
            {
                return _clusters.ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.Support ?? 0);
            }
        }

        private string GetNextLabel()
        {
            var label = IndexToLabel(_nextLabelIndex);
            _nextLabelIndex++;
            return label;
        }

        private static string IndexToLabel(int index)
        {
            var result = new List<char>();
            int remaining = index;

            do
            {
                result.Insert(0, (char)('A' + (remaining % 26)));
                remaining = remaining / 26 - 1;
            } while (remaining >= 0);

            return LabelPrefix + new string(result.ToArray());
        }

        private static double Clamp01(double v) => v < 0 ? 0 : (v > 1 ? 1 : v);

        private static void UpdateCentroid(Cluster c, float[] emb, double alpha)
        {
            if (c?.Centroid == null || emb == null) return;
            var cent = c.Centroid;
            int len = Math.Min(cent.Length, emb.Length);
            for (int i = 0; i < len; i++)
                cent[i] = (float)((1.0 - alpha) * cent[i] + alpha * emb[i]);
        }

        private static double CosineSimilarity(float[] a, float[] b)
        {
            if (a == null || b == null || a.Length == 0 || b.Length == 0) return -1.0;

            int len = Math.Min(a.Length, b.Length);
            double dot = 0, normA = 0, normB = 0;

            for (int i = 0; i < len; i++)
            {
                dot += a[i] * b[i];
                normA += a[i] * a[i];
                normB += b[i] * b[i];
            }

            if (normA < 1e-9 || normB < 1e-9) return -1.0;
            return dot / (Math.Sqrt(normA) * Math.Sqrt(normB));
        }

        private static double GetSameSpeakerThreshold()
        {
            try
            {
                var v = App.SettingsProvider?.Current?.Transcription?.DiarizationSimilarityThreshold;
                if (v.HasValue && v.Value >= 0 && v.Value <= 1)
                {
                    // IMPORTANT: no remap. Settings are interpreted directly on ECAPA cosine scale.
                    return v.Value;
                }
            }
            catch { }

            return DefaultSameSpeakerThreshold;
        }

        private static double GetNewSpeakerThreshold()
        {
            // New speaker threshold should be lower than same-speaker matching.
            // If settings are present, derive a slightly lower new-speaker threshold.
            var same = GetSameSpeakerThreshold();
            return Math.Max(0.10, Math.Min(same - 0.10, DefaultNewSpeakerThreshold));
        }

        private static DateTime _lastThresholdLog = DateTime.MinValue;

        private static double GetMinSwitchMargin()
        {
            double s = 0.5;
            try
            {
                var v = App.SettingsProvider?.Current?.Transcription?.DiarizationSimilarityThreshold;
                if (v.HasValue) s = Math.Max(0.0, Math.Min(1.0, v.Value));
            }
            catch { }

            // Ensure a sensible floor even if settings are low.
            // ECAPA cosine: start around 0.05.
            return Math.Max(DefaultMinMargin, 0.05);
        }

        private static int GetMaxClusters()
        {
            double s = 0.5;
            try
            {
                var v = App.SettingsProvider?.Current?.Transcription?.DiarizationSimilarityThreshold;
                if (v.HasValue) s = Math.Max(0.0, Math.Min(1.0, v.Value));
            }
            catch { }

            // Prefer the old mapping if it yields higher, but cap at a sensible interview-friendly maximum.
            var mapped = 6 + (int)Math.Round(s * 6.0);
            return Math.Max(DefaultMaxClusters, Math.Min(12, mapped));
        }

        private bool ShouldCreateNewSpeaker(double bestScore, double newSpkThr, DateTime now, int maxClusters)
        {
            if (_clusters.Count >= maxClusters) return false;

            if (_lastNewSpeakerUtc != DateTime.MinValue &&
                (now - _lastNewSpeakerUtc).TotalMilliseconds < DefaultNewSpeakerCooldownMs)
                return false;

            if (bestScore < newSpkThr) _belowNewSpeakerThresholdCount++;
            else _belowNewSpeakerThresholdCount = 0;

            if (_belowNewSpeakerThresholdCount < DefaultNewSpeakerConsecutive)
                return false;

            _belowNewSpeakerThresholdCount = 0;
            _lastNewSpeakerUtc = now;
            return true;
        }

        public void ObserveFrame(long startSample, long endSample, string label, float score)
        {
            if (endSample <= startSample) return;
            if (string.IsNullOrWhiteSpace(label)) return;

            lock (_lock)
            {
                _timeline.Add((startSample, endSample, label, score));
                if (_timeline.Count > MaxTimeline)
                    _timeline.RemoveRange(0, _timeline.Count - MaxTimeline);
            }
        }

        public string GetDominantSpeaker(long startSample, long endSample, string fallback = "Unknown")
        {
            if (endSample <= startSample) return fallback;

            lock (_lock)
            {
                if (_timeline.Count == 0) return fallback;

                var totals = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

                foreach (var (s, e, label, score) in _timeline)
                {
                    if (e <= startSample || s >= endSample) continue;

                    var os = Math.Max(s, startSample);
                    var oe = Math.Min(e, endSample);
                    var dur = Math.Max(0, oe - os);
                    if (dur <= 0) continue;

                    var w = dur * Math.Max(0.0, score);
                    totals.TryGetValue(label, out var cur);
                    totals[label] = cur + w;
                }

                if (totals.Count == 0) return fallback;
                return totals.OrderByDescending(kv => kv.Value).First().Key;
            }
        }
    }
}
