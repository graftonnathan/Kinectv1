using System;
using System.Collections.Generic;
using System.Linq;

namespace Kinectv1.Services.Transcription
{
    /// <summary>
    /// Speaker diarization for transcription mode.
    /// Tracks and labels speakers (Speaker A, B, C...) based on voice embeddings
    /// when speakers are not enrolled in the main SpeakerIdentifier.
    /// </summary>
    public sealed class SpeakerDiarizer
    {
        private static readonly Lazy<SpeakerDiarizer> _instance = new(() => new SpeakerDiarizer());
        public static SpeakerDiarizer Instance => _instance.Value;

        private sealed class Cluster
        {
            public string Label;
            public float[] Centroid;
            public int Support;
            public DateTime LastSeenUtc;
        }

        // Speaker clusters: label -> centroid/stats
        private readonly Dictionary<string, Cluster> _clusters = new(StringComparer.OrdinalIgnoreCase);
        private readonly object _lock = new();

        private int _nextLabelIndex = 0;

        // Tunables (fallback defaults)
        // ECAPA / WeSpeaker cosine similarity defaults (starting points)
        private const double DefaultSameSpeakerThreshold = 0.45;
        private const double DefaultNewSpeakerThreshold = 0.35;
        private const double DefaultMinMargin = 0.05;
        private const double DefaultUpdateAlpha = 0.08;
        private const int DefaultNewSpeakerConsecutive = 4;
        private const int DefaultNewSpeakerCooldownMs = 3000;
        private const int DefaultMaxClusters = 6;
        private const double DefaultOverlapScoreBand = 0.03;

        // Anti-ping-pong switching guards
        private const double DefaultMinSwitchMargin = 0.05;
        private const int DefaultMinSpeakerHoldMs = 800;

        private const string LabelPrefix = "Speaker ";

        private DateTime _lastNewSpeakerUtc = DateTime.MinValue;
        private int _belowNewSpeakerThresholdCount = 0;

        private string _currentSpeaker = null;
        private DateTime _lastSwitchUtc = DateTime.MinValue;

        private SpeakerDiarizer() { }

        public void Reset()
        {
            lock (_lock)
            {
                _clusters.Clear();
                _nextLabelIndex = 0;
                _lastNewSpeakerUtc = DateTime.MinValue;
                _belowNewSpeakerThresholdCount = 0;
                _currentSpeaker = null;
                _lastSwitchUtc = DateTime.MinValue;
                Console.WriteLine("[Diarizer] Reset - all clusters cleared");
            }
        }

        public int SpeakerCount
        {
            get { lock (_lock) return _clusters.Count; }
        }

        public string[] GetSpeakerLabels()
        {
            lock (_lock)
            {
                return _clusters.Keys.OrderBy(k => k).ToArray();
            }
        }

        public (string label, float confidence) IdentifyOrAssign(float[] embedding)
        {
            if (embedding == null || embedding.Length == 0) return ("Unknown", 0f);
            for (int i = 0; i < embedding.Length; i++)
            {
                if (float.IsNaN(embedding[i]) || float.IsInfinity(embedding[i]))
                    return ("Unknown", 0f);
            }

            lock (_lock)
            {
                double sameThr = GetSameSpeakerThreshold();
                double newThr = GetNewSpeakerThreshold();
                double minMargin = GetMinSwitchMargin();
                int maxClusters = GetMaxClusters();

                // First speaker always
                if (_clusters.Count == 0)
                {
                    var label0 = GetNextLabel();
                    _clusters[label0] = new Cluster
                    {
                        Label = label0,
                        Centroid = (float[])embedding.Clone(),
                        Support = 1,
                        LastSeenUtc = DateTime.UtcNow
                    };
                    _lastNewSpeakerUtc = DateTime.UtcNow;
                    _belowNewSpeakerThresholdCount = 0;
                    _currentSpeaker = label0;
                    _lastSwitchUtc = DateTime.UtcNow;
                    return (label0, 1f);
                }

                // Find best + second best
                string best = null, second = null;
                double bestScore = double.NegativeInfinity;
                double secondScore = double.NegativeInfinity;

                foreach (var kv in _clusters)
                {
                    var sim = CosineSimilarity(embedding, kv.Value.Centroid);
                    if (sim > bestScore)
                    {
                        secondScore = bestScore; second = best;
                        bestScore = sim; best = kv.Key;
                    }
                    else if (sim > secondScore)
                    {
                        secondScore = sim; second = kv.Key;
                    }
                }

                double margin = bestScore - secondScore;

                // Soft overlap indicator
                bool nearThreshold = bestScore < (sameThr + DefaultOverlapScoreBand);
                bool lowMargin = _clusters.Count >= 2 && margin < minMargin;
                bool overlapped = (_clusters.Count >= 2) && (nearThreshold || lowMargin);

                // Confidence weight (0..1)
                double scoreConf = Clamp01((bestScore - sameThr) / 0.10);
                double marginConf = (_clusters.Count < 2) ? 1.0 : Clamp01(margin / (minMargin * 2.0));
                double w = scoreConf * marginConf;

                var now = DateTime.UtcNow;

                // Initialize tracking if needed
                if (string.IsNullOrWhiteSpace(_currentSpeaker) || !_clusters.ContainsKey(_currentSpeaker))
                    _currentSpeaker = best;

                // Logging (keep existing pattern)
                bool isSignificantEvent = (best != null && bestScore < sameThr) || (_clusters.Count > 1 && margin < 0.1);
                bool shouldLog = _clusters.Count > 0 && ((now - _lastLogTime).TotalSeconds >= 10.0 || isSignificantEvent);
                if (shouldLog)
                {
                    Console.WriteLine($"[Diarizer] Scores: best={best}({bestScore:F3}), second={second}({secondScore:F3}), margin={margin:F3}, sameThr={sameThr:F3}, newThr={newThr:F3}, clusters={_clusters.Count}");
                    _lastLogTime = now;
                }

                // Anti-chatter: minimum hold time before allowing switches.
                // If we are within the hold window, keep the current speaker stable.
                if (!string.IsNullOrWhiteSpace(_currentSpeaker) && _lastSwitchUtc != DateTime.MinValue &&
                    (now - _lastSwitchUtc).TotalMilliseconds < DefaultMinSpeakerHoldMs)
                {
                    // Still allow learning on very confident frames for the locked speaker.
                    if (_clusters.TryGetValue(_currentSpeaker, out var holdCluster))
                    {
                        var holdScore = CosineSimilarity(embedding, holdCluster.Centroid);
                        bool canLearnHold = holdScore >= (sameThr + 0.05);
                        if (canLearnHold)
                            UpdateCentroid(holdCluster, embedding, alpha: DefaultUpdateAlpha);
                        holdCluster.LastSeenUtc = now;
                    }
                    return (_currentSpeaker, (float)Math.Max(0.01, bestScore));
                }

                // Switch gating: only consider switching on strong, unambiguous evidence.
                // If margin is tiny, don't advance any state and don't learn.
                bool strongEnoughToDecide = bestScore >= sameThr && margin >= Math.Max(minMargin, DefaultMinSwitchMargin);
                if (!strongEnoughToDecide)
                {
                    return (!string.IsNullOrWhiteSpace(_currentSpeaker) ? _currentSpeaker : (best ?? "Unknown"),
                        (float)Math.Max(0.01, bestScore));
                }

                // Match
                if (!string.IsNullOrWhiteSpace(best) && bestScore >= sameThr)
                {
                    var c = _clusters[best];

                    // Reduce centroid drift: only update on confident matches.
                    //  - For 1 cluster, require a bit above sameThr.
                    //  - For 2+ clusters, also require margin.
                    bool canLearn = bestScore >= (sameThr + 0.05) && margin >= 0.06;
                    if (canLearn && w > 0.05)
                    {
                        UpdateCentroid(c, embedding, alpha: DefaultUpdateAlpha * w);
                        c.Support++;
                    }
                    c.LastSeenUtc = now;

                    // Reset unknown streak on confident match
                    if (w >= 0.2)
                        _belowNewSpeakerThresholdCount = 0;

                    // Speaker switch bookkeeping (only when we really changed label)
                    if (!string.IsNullOrWhiteSpace(best) && !string.Equals(_currentSpeaker, best, StringComparison.OrdinalIgnoreCase))
                    {
                        _currentSpeaker = best;
                        _lastSwitchUtc = now;
                    }
                    else if (!string.IsNullOrWhiteSpace(best))
                    {
                        _currentSpeaker = best;
                    }

                    return (best, (float)bestScore);
                }

                // Below threshold: candidate for new speaker
                if (!overlapped && ShouldCreateNewSpeaker(bestScore, newThr, now, maxClusters))
                {
                    var newLabel = GetNextLabel();
                    _clusters[newLabel] = new Cluster
                    {
                        Label = newLabel,
                        Centroid = (float[])embedding.Clone(),
                        Support = 1,
                        LastSeenUtc = now
                    };

                    _lastNewSpeakerUtc = now;
                    _belowNewSpeakerThresholdCount = 0;
                    _currentSpeaker = newLabel;
                    _lastSwitchUtc = now;
                    Console.WriteLine($"[Diarizer] NEW SPEAKER: {newLabel} (best={best}:{bestScore:F3} < newThr={newThr:F3}, clusters={_clusters.Count})");
                    return (newLabel, 1f);
                }

                // Hard clamp: if we're already at/over max clusters, never create new labels.
                // Return best guess or Unknown.
                if (!string.IsNullOrWhiteSpace(best))
                {
                    if (string.IsNullOrWhiteSpace(_currentSpeaker)) _currentSpeaker = best;
                    return (best, (float)Math.Max(0.01, bestScore));
                }

                return ("Unknown", 0f);
            }
        }

        private static DateTime _lastLogTime = DateTime.MinValue;

        public (string label, float confidence) Identify(float[] embedding)
        {
            if (embedding == null || embedding.Length == 0) return ("Unknown", 0f);

            lock (_lock)
            {
                if (_clusters.Count == 0) return ("Unknown", 0f);

                string best = null;
                double bestScore = double.NegativeInfinity;

                foreach (var kv in _clusters)
                {
                    var sim = CosineSimilarity(embedding, kv.Value.Centroid);
                    if (sim > bestScore)
                    {
                        bestScore = sim;
                        best = kv.Key;
                    }
                }

                double thr = GetSameSpeakerThreshold();
                if (best != null && bestScore >= thr)
                    return (best, (float)bestScore);

                return ("Unknown", (float)Math.Max(0, bestScore));
            }
        }

        public bool MergeSpeakers(string label1, string label2)
        {
            // Online auto-merge is intentionally avoided; manual merge kept for operator corrections.
            lock (_lock)
            {
                if (!_clusters.TryGetValue(label1, out var c1) || !_clusters.TryGetValue(label2, out var c2))
                    return false;

                if (c1?.Centroid == null || c2?.Centroid == null) return false;

                // Merge by averaging centroids weighted by support.
                int w1 = Math.Max(1, c1.Support);
                int w2 = Math.Max(1, c2.Support);
                int tot = w1 + w2;

                for (int i = 0; i < c1.Centroid.Length && i < c2.Centroid.Length; i++)
                    c1.Centroid[i] = (float)((c1.Centroid[i] * w1 + c2.Centroid[i] * w2) / tot);

                c1.Support = tot;
                c1.LastSeenUtc = DateTime.UtcNow;

                _clusters.Remove(label2);
                Console.WriteLine($"[Diarizer] Merged {label2} into {label1}");
                return true;
            }
        }

        public Dictionary<string, int> GetClusterStats()
        {
            lock (_lock)
            {
                return _clusters.ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.Support ?? 0);
            }
        }

        private string GetNextLabel()
        {
            var label = IndexToLabel(_nextLabelIndex);
            _nextLabelIndex++;
            return label;
        }

        private static string IndexToLabel(int index)
        {
            var result = new List<char>();
            int remaining = index;

            do
            {
                result.Insert(0, (char)('A' + (remaining % 26)));
                remaining = remaining / 26 - 1;
            } while (remaining >= 0);

            return LabelPrefix + new string(result.ToArray());
        }

        private static double Clamp01(double v) => v < 0 ? 0 : (v > 1 ? 1 : v);

        private static void UpdateCentroid(Cluster c, float[] emb, double alpha)
        {
            if (c?.Centroid == null || emb == null) return;
            var cent = c.Centroid;
            int len = Math.Min(cent.Length, emb.Length);
            for (int i = 0; i < len; i++)
                cent[i] = (float)((1.0 - alpha) * cent[i] + alpha * emb[i]);
        }

        private static double CosineSimilarity(float[] a, float[] b)
        {
            if (a == null || b == null || a.Length == 0 || b.Length == 0) return -1.0;

            int len = Math.Min(a.Length, b.Length);
            double dot = 0, normA = 0, normB = 0;

            for (int i = 0; i < len; i++)
            {
                dot += a[i] * b[i];
                normA += a[i] * a[i];
                normB += b[i] * b[i];
            }

            if (normA < 1e-9 || normB < 1e-9) return -1.0;
            return dot / (Math.Sqrt(normA) * Math.Sqrt(normB));
        }

        private static double GetSameSpeakerThreshold()
        {
            try
            {
                var v = App.SettingsProvider?.Current?.Transcription?.DiarizationSimilarityThreshold;
                if (v.HasValue && v.Value >= 0 && v.Value <= 1)
                {
                    // IMPORTANT: no remap. Settings are interpreted directly on ECAPA cosine scale.
                    return v.Value;
                }
            }
            catch { }

            return DefaultSameSpeakerThreshold;
        }

        private static double GetNewSpeakerThreshold()
        {
            // New speaker threshold should be lower than same-speaker matching.
            // If settings are present, derive a slightly lower new-speaker threshold.
            var same = GetSameSpeakerThreshold();
            return Math.Max(0.10, Math.Min(same - 0.10, DefaultNewSpeakerThreshold));
        }

        private static DateTime _lastThresholdLog = DateTime.MinValue;

        private static double GetMinSwitchMargin()
        {
            double s = 0.5;
            try
            {
                var v = App.SettingsProvider?.Current?.Transcription?.DiarizationSimilarityThreshold;
                if (v.HasValue) s = Math.Max(0.0, Math.Min(1.0, v.Value));
            }
            catch { }

            // Ensure a sensible floor even if settings are low.
            // ECAPA cosine: start around 0.05.
            return Math.Max(DefaultMinMargin, 0.05);
        }

        private static int GetMaxClusters()
        {
            double s = 0.5;
            try
            {
                var v = App.SettingsProvider?.Current?.Transcription?.DiarizationSimilarityThreshold;
                if (v.HasValue) s = Math.Max(0.0, Math.Min(1.0, v.Value));
            }
            catch { }

            // Prefer the old mapping if it yields higher, but cap at a sensible interview-friendly maximum.
            var mapped = 6 + (int)Math.Round(s * 6.0);
            return Math.Max(DefaultMaxClusters, Math.Min(12, mapped));
        }

        private bool ShouldCreateNewSpeaker(double bestScore, double newSpkThr, DateTime now, int maxClusters)
        {
            if (_clusters.Count >= maxClusters) return false;

            if (_lastNewSpeakerUtc != DateTime.MinValue &&
                (now - _lastNewSpeakerUtc).TotalMilliseconds < DefaultNewSpeakerCooldownMs)
                return false;

            if (bestScore < newSpkThr) _belowNewSpeakerThresholdCount++;
            else _belowNewSpeakerThresholdCount = 0;

            if (_belowNewSpeakerThresholdCount < DefaultNewSpeakerConsecutive)
                return false;

            _belowNewSpeakerThresholdCount = 0;
            _lastNewSpeakerUtc = now;
            return true;
        }
    }
}
