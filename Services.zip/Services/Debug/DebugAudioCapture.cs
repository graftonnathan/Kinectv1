using System;
using System.IO;
using System.Threading;
using Kinectv1.Settings;
using Kinectv1.Voice;
using NAudio.Wave;

namespace Kinectv1.Services.Debug
{
    /// <summary>
    /// Captures audio frames for debugging and saves them as WAV files.
    /// Supports two modes:
    /// - Raw mode (default): Captures ALL audio continuously without VAD gating
    /// - VAD mode: Only captures when voice is detected (can cause clicks/pops)
    /// </summary>
    public static class DebugAudioCapture
    {
        private static readonly object _lock = new object();
        private static bool _captureActive;
        private static string _outputFolder;
        private static WaveFileWriter _writer;
        private static string _currentFilePath;
        private static DateTime _sessionStart;
        private static int _frameCount;
        private static int _clipCount;
        private static float _lastRms;
        private static float _peakRms;
        private static DateTime _peakTime;
        
        // Raw capture mode - writes ALL frames without VAD gating (recommended)
        private static bool _rawCaptureMode = true;
        
        // VAD for smart capture - only used when _rawCaptureMode = false
        private static double _vadThreshold = 150.0;
        private static int _silentFrameCount = 0;
        private static int _activeFrameCount = 0;
        private const int SILENCE_FRAMES_BEFORE_PAUSE = 25;
        private const int ACTIVE_FRAMES_BEFORE_RESUME = 2;
        private static bool _vadActive = false;
        
        // Statistics for diagnostics
        private static int _zeroFrameCount = 0;
        private static int _totalFramesSeen = 0;

        // Crossfade buffer for smooth chunk boundaries (only used in VAD mode)
        private const int CROSSFADE_SAMPLES = 64; // ~4ms @ 16kHz
        private static short[] _lastSamples = new short[CROSSFADE_SAMPLES];
        private static int _lastSamplesCount = 0;
        private static bool _isFirstChunk = true;

        // Audio format: 16kHz, 16-bit, mono (matches Vosk input)
        private const int SampleRate = 16000;
        private const int BitsPerSample = 16;
        private const int Channels = 1;

        /// <summary>
        /// Event fired when a new capture file is created.
        /// </summary>
        public static event Action<string> OnCaptureFileCreated;

        /// <summary>
        /// Event fired when capture status changes.
        /// </summary>
        public static event Action<string> OnStatusChanged;

        /// <summary>
        /// Event fired when RMS level is updated (for UI feedback).
        /// </summary>
        public static event Action<float> OnRmsLevel;

        /// <summary>
        /// Gets whether audio capture is currently active.
        /// </summary>
        public static bool IsCapturing => _captureActive && _writer != null;

        /// <summary>
        /// Gets the current capture file path, or null if not capturing.
        /// </summary>
        public static string CurrentFilePath => _currentFilePath;

        /// <summary>
        /// Gets the number of frames captured in the current session.
        /// </summary>
        public static int FrameCount => _frameCount;

        /// <summary>
        /// Gets the last RMS level (0-10000 scale).
        /// </summary>
        public static float LastRms => _lastRms;

        /// <summary>
        /// Gets the peak RMS level since last reset (0-10000 scale).
        /// </summary>
        public static float PeakRms => _peakRms;

        /// <summary>
        /// Gets whether VAD is currently detecting voice activity.
        /// In raw mode, this always returns true when capturing.
        /// </summary>
        public static bool IsVadActive => _rawCaptureMode ? _captureActive : _vadActive;

        /// <summary>
        /// Gets the count of zero/silent frames detected (diagnostic).
        /// </summary>
        public static int ZeroFrameCount => _zeroFrameCount;

        /// <summary>
        /// Gets the total frames seen (diagnostic).
        /// </summary>
        public static int TotalFramesSeen => _totalFramesSeen;

        /// <summary>
        /// Gets or sets whether raw capture mode is enabled.
        /// When true (default), ALL audio is written without VAD gating.
        /// </summary>
        public static bool RawCaptureMode
        {
            get => _rawCaptureMode;
            set
            {
                _rawCaptureMode = value;
                Console.WriteLine($"[DebugAudioCapture] Raw capture mode: {value}");
            }
        }

        /// <summary>
        /// Initialize the debug audio capture.
        /// </summary>
        public static void Initialize()
        {
            try
            {
                var debug = App.SettingsProvider?.Current?.Debug;
                if (debug != null)
                {
                    _outputFolder = debug.AudioCaptureFolder ?? "debug_audio";
                }

                var audio = App.SettingsProvider?.Current?.Audio;
                if (audio != null)
                {
                    _vadThreshold = Math.Max(50.0, audio.VoiceThreshold * 10000.0 * 0.5);
                }

                // Default to raw capture mode to avoid audio quality issues
                _rawCaptureMode = true;

                Console.WriteLine($"[DebugAudioCapture] Initialized (folder={_outputFolder}, vadThreshold={_vadThreshold:F0}, rawMode={_rawCaptureMode})");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DebugAudioCapture] Init error: {ex.Message}");
            }
        }

        /// <summary>
        /// Manually start capture.
        /// </summary>
        public static void StartCapture()
        {
            lock (_lock)
            {
                try
                {
                    StopCaptureInternal();

                    var folder = ResolvePath(_outputFolder ?? "debug_audio");
                    if (!Directory.Exists(folder))
                    {
                        Directory.CreateDirectory(folder);
                    }

                    _sessionStart = DateTime.Now;
                    _clipCount++;
                    var filename = $"stt_input_{_sessionStart:yyyy-MM-dd_HH-mm-ss}_{_clipCount:D3}.wav";
                    _currentFilePath = Path.Combine(folder, filename);

                    var format = new WaveFormat(SampleRate, BitsPerSample, Channels);
                    _writer = new WaveFileWriter(_currentFilePath, format);
                    _frameCount = 0;
                    _peakRms = 0;
                    _lastRms = 0;
                    _silentFrameCount = 0;
                    _activeFrameCount = 0;
                    _vadActive = false;
                    _zeroFrameCount = 0;
                    _totalFramesSeen = 0;
                    
                    // Reset crossfade state
                    _lastSamplesCount = 0;
                    _isFirstChunk = true;
                    Array.Clear(_lastSamples, 0, _lastSamples.Length);

                    _captureActive = true;

                    var audio = App.SettingsProvider?.Current?.Audio;
                    if (audio != null)
                    {
                        _vadThreshold = Math.Max(50.0, audio.VoiceThreshold * 10000.0 * 0.5);
                    }

                    var modeStr = _rawCaptureMode ? "RAW (continuous)" : "VAD-gated";
                    Console.WriteLine($"[DebugAudioCapture] Started: {_currentFilePath} (mode={modeStr}, vadThreshold={_vadThreshold:F0})");
                    OnStatusChanged?.Invoke($"Recording ({modeStr}): {Path.GetFileName(_currentFilePath)}");
                    OnCaptureFileCreated?.Invoke(_currentFilePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[DebugAudioCapture] Start error: {ex.Message}");
                    OnStatusChanged?.Invoke($"Error: {ex.Message}");
                    _writer = null;
                    _currentFilePath = null;
                    _captureActive = false;
                }
            }
        }

        /// <summary>
        /// Stop the current capture session.
        /// </summary>
        public static void StopCapture()
        {
            lock (_lock)
            {
                _captureActive = false;
                StopCaptureInternal();
            }
        }

        private static void StopCaptureInternal()
        {
            try
            {
                if (_writer != null)
                {
                    var path = _currentFilePath;
                    var frames = _frameCount;
                    var zeroPercent = _totalFramesSeen > 0 ? (100.0 * _zeroFrameCount / _totalFramesSeen) : 0;

                    _writer.Flush();
                    _writer.Dispose();
                    _writer = null;

                    Console.WriteLine($"[DebugAudioCapture] Stopped: {path} ({frames} frames written, {_zeroFrameCount}/{_totalFramesSeen} zero frames = {zeroPercent:F1}%)");
                    OnStatusChanged?.Invoke($"Saved: {Path.GetFileName(path)} ({frames} frames, {zeroPercent:F0}% zero)");
                }
                _currentFilePath = null;
                _frameCount = 0;
                _lastSamplesCount = 0;
                _isFirstChunk = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DebugAudioCapture] Stop error: {ex.Message}");
            }
        }

        /// <summary>
        /// Capture raw PCM16 audio data. Called BEFORE VAD gating for continuous capture.
        /// In raw mode, writes ALL frames directly.
        /// In VAD mode, uses VAD gating with crossfade at boundaries.
        /// </summary>
        /// <param name="pcm16">PCM16 little-endian mono audio data.</param>
        /// <param name="length">Number of valid bytes in the array.</param>
        public static void CaptureRaw(byte[] pcm16, int length)
        {
            if (pcm16 == null || length <= 0) return;

            // Always compute and report RMS for UI feedback
            float rms = ComputeRms(pcm16, length);
            _lastRms = rms;
            if (rms > _peakRms)
            {
                _peakRms = rms;
                _peakTime = DateTime.UtcNow;
            }

            if ((DateTime.UtcNow - _peakTime).TotalSeconds > 2)
            {
                _peakRms = _peakRms * 0.95f;
            }

            try { OnRmsLevel?.Invoke(rms); } catch { }

            if (!_captureActive) return;

            lock (_lock)
            {
                if (_writer == null || !_captureActive) return;

                try
                {
                    _totalFramesSeen++;

                    bool isZeroFrame = rms < 1.0f;
                    if (isZeroFrame)
                    {
                        _zeroFrameCount++;
                    }

                    // RAW MODE: Write everything directly - no VAD, no clicks
                    if (_rawCaptureMode)
                    {
                        _writer.Write(pcm16, 0, length);
                        Interlocked.Increment(ref _frameCount);
                        return;
                    }

                    // VAD MODE: Gate audio with crossfade (legacy behavior)
                    CaptureWithVadGating(pcm16, length, rms);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[DebugAudioCapture] Write error: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// VAD-gated capture with crossfade (legacy mode).
        /// </summary>
        private static void CaptureWithVadGating(byte[] pcm16, int length, float rms)
        {
            // VAD gating with hysteresis
            bool wasVadActive = _vadActive;
            if (rms >= _vadThreshold)
            {
                _silentFrameCount = 0;
                _activeFrameCount++;
                
                if (!_vadActive && _activeFrameCount >= ACTIVE_FRAMES_BEFORE_RESUME)
                {
                    _vadActive = true;
                }
            }
            else
            {
                _activeFrameCount = 0;
                _silentFrameCount++;
                
                if (_vadActive && _silentFrameCount >= SILENCE_FRAMES_BEFORE_PAUSE)
                {
                    _vadActive = false;
                }
            }

            // Write with crossfade at VAD transitions to avoid clicks
            if (_vadActive)
            {
                int samples = length / 2;
                var outputBytes = new byte[length];
                
                if (!wasVadActive && _lastSamplesCount > 0)
                {
                    ApplyCrossfadeIn(pcm16, length, outputBytes);
                }
                else if (_isFirstChunk)
                {
                    Buffer.BlockCopy(pcm16, 0, outputBytes, 0, length);
                    _isFirstChunk = false;
                }
                else
                {
                    ApplyCrossfadeWithPrevious(pcm16, length, outputBytes);
                }
                
                _writer.Write(outputBytes, 0, length);
                Interlocked.Increment(ref _frameCount);
                
                StoreTailSamples(pcm16, length);
            }
            else if (wasVadActive)
            {
                WriteFadeOutTail();
            }
        }

        /// <summary>
        /// Apply crossfade from previous chunk's tail to current chunk's head.
        /// </summary>
        private static void ApplyCrossfadeWithPrevious(byte[] input, int length, byte[] output)
        {
            int samples = length / 2;
            int crossfadeSamples = Math.Min(CROSSFADE_SAMPLES, Math.Min(_lastSamplesCount, samples));
            
            for (int i = 0; i < samples; i++)
            {
                int byteIdx = i * 2;
                short currentSample = (short)(input[byteIdx] | (input[byteIdx + 1] << 8));
                
                if (i < crossfadeSamples && _lastSamplesCount > 0)
                {
                    float t = (float)i / crossfadeSamples;
                    short prevSample = _lastSamples[_lastSamplesCount - crossfadeSamples + i];
                    short blended = (short)(prevSample * (1.0f - t) + currentSample * t);
                    output[byteIdx] = (byte)(blended & 0xFF);
                    output[byteIdx + 1] = (byte)((blended >> 8) & 0xFF);
                }
                else
                {
                    output[byteIdx] = input[byteIdx];
                    output[byteIdx + 1] = input[byteIdx + 1];
                }
            }
        }

        /// <summary>
        /// Apply fade-in from silence at VAD onset.
        /// </summary>
        private static void ApplyCrossfadeIn(byte[] input, int length, byte[] output)
        {
            int samples = length / 2;
            int fadeSamples = Math.Min(CROSSFADE_SAMPLES, samples);
            
            for (int i = 0; i < samples; i++)
            {
                int byteIdx = i * 2;
                short currentSample = (short)(input[byteIdx] | (input[byteIdx + 1] << 8));
                
                if (i < fadeSamples)
                {
                    float t = (float)i / fadeSamples;
                    short faded = (short)(currentSample * t);
                    output[byteIdx] = (byte)(faded & 0xFF);
                    output[byteIdx + 1] = (byte)((faded >> 8) & 0xFF);
                }
                else
                {
                    output[byteIdx] = input[byteIdx];
                    output[byteIdx + 1] = input[byteIdx + 1];
                }
            }
        }

        /// <summary>
        /// Write a fade-out tail when VAD turns off.
        /// </summary>
        private static void WriteFadeOutTail()
        {
            if (_lastSamplesCount <= 0 || _writer == null) return;
            
            int fadeSamples = Math.Min(CROSSFADE_SAMPLES, _lastSamplesCount);
            var fadeOut = new byte[fadeSamples * 2];
            
            for (int i = 0; i < fadeSamples; i++)
            {
                float t = 1.0f - ((float)i / fadeSamples);
                short sample = _lastSamples[_lastSamplesCount - fadeSamples + i];
                short faded = (short)(sample * t);
                fadeOut[i * 2] = (byte)(faded & 0xFF);
                fadeOut[i * 2 + 1] = (byte)((faded >> 8) & 0xFF);
            }
            
            _writer.Write(fadeOut, 0, fadeOut.Length);
        }

        /// <summary>
        /// Store the tail samples from current chunk for next crossfade.
        /// </summary>
        private static void StoreTailSamples(byte[] pcm16, int length)
        {
            int samples = length / 2;
            int toStore = Math.Min(CROSSFADE_SAMPLES, samples);
            
            for (int i = 0; i < toStore; i++)
            {
                int srcIdx = (samples - toStore + i) * 2;
                _lastSamples[i] = (short)(pcm16[srcIdx] | (pcm16[srcIdx + 1] << 8));
            }
            _lastSamplesCount = toStore;
        }

        /// <summary>
        /// Manually rotate to a new capture file.
        /// </summary>
        public static void RotateFile()
        {
            if (!_captureActive) return;
            
            lock (_lock)
            {
                StopCaptureInternal();
                
                try
                {
                    var folder = ResolvePath(_outputFolder ?? "debug_audio");
                    if (!Directory.Exists(folder))
                    {
                        Directory.CreateDirectory(folder);
                    }

                    _sessionStart = DateTime.Now;
                    _clipCount++;
                    var filename = $"stt_input_{_sessionStart:yyyy-MM-dd_HH-mm-ss}_{_clipCount:D3}.wav";
                    _currentFilePath = Path.Combine(folder, filename);

                    var format = new WaveFormat(SampleRate, BitsPerSample, Channels);
                    _writer = new WaveFileWriter(_currentFilePath, format);
                    _frameCount = 0;
                    _silentFrameCount = 0;
                    _activeFrameCount = 0;
                    _vadActive = false;
                    _zeroFrameCount = 0;
                    _totalFramesSeen = 0;
                    _lastSamplesCount = 0;
                    _isFirstChunk = true;

                    Console.WriteLine($"[DebugAudioCapture] Rotated to: {_currentFilePath}");
                    OnStatusChanged?.Invoke($"Recording: {Path.GetFileName(_currentFilePath)}");
                    OnCaptureFileCreated?.Invoke(_currentFilePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[DebugAudioCapture] Rotate error: {ex.Message}");
                    _captureActive = false;
                }
            }
        }

        /// <summary>
        /// Reset the peak RMS level.
        /// </summary>
        public static void ResetPeak()
        {
            _peakRms = 0;
        }

        /// <summary>
        /// Get the resolved output folder path.
        /// </summary>
        public static string GetOutputFolder()
        {
            return ResolvePath(_outputFolder ?? "debug_audio");
        }

        /// <summary>
        /// Set the output folder path.
        /// </summary>
        public static void SetOutputFolder(string folder)
        {
            _outputFolder = folder ?? "debug_audio";
        }

        private static string ResolvePath(string path)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(path)) return path;
                var expanded = Environment.ExpandEnvironmentVariables(path);
                if (!Path.IsPathRooted(expanded))
                    expanded = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, expanded);
                return Path.GetFullPath(expanded);
            }
            catch { return path; }
        }

        /// <summary>
        /// Compute RMS from PCM16 byte buffer (0-10000 scale).
        /// </summary>
        private static float ComputeRms(byte[] buffer, int length)
        {
            if (buffer == null || length <= 0) return 0f;
            int samples = length / 2;
            if (samples == 0) return 0f;

            double sumSquares = 0.0;
            for (int i = 0; i < samples; i++)
            {
                int bi = i * 2;
                if (bi + 1 >= length) break;
                short sample = (short)(buffer[bi] | (buffer[bi + 1] << 8));
                double norm = sample / 32768.0;
                sumSquares += norm * norm;
            }

            double mean = sumSquares / samples;
            return (float)(Math.Sqrt(mean) * 10000.0);
        }
    }
}
